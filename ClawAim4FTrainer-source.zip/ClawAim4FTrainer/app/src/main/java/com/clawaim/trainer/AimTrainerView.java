package com.clawaim.trainer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class AimTrainerView extends View {
    private enum Screen { HOME, TRAINING, HUD_EDIT, SENSITIVITY }
    private enum Mode { FLICK, TRACKING, SWITCHING, REACTION, RECOIL }

    private static final int BG = Color.rgb(11, 17, 23);
    private static final int PANEL = Color.rgb(24, 34, 43);
    private static final int PANEL2 = Color.rgb(31, 45, 56);
    private static final int TEXT = Color.rgb(235, 242, 246);
    private static final int MUTED = Color.rgb(145, 164, 176);
    private static final int ACCENT = Color.rgb(64, 219, 169);
    private static final int TARGET = Color.rgb(255, 83, 83);
    private static final int TARGET_RING = Color.rgb(255, 183, 74);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final SharedPreferences prefs;
    private final Vibrator vibrator;

    private Screen screen = Screen.HOME;
    private Mode mode = Mode.FLICK;
    private int sessionSeconds = 60;
    private int selectedScope = 1; // 0 hip, 1=1x, 2=2x ... 12

    private final float[] cameraSens = {190,150,140,125,110,100,90,85,80,75,70,65,60};
    private final float[] firingSens = {180,160,145,130,115,105,95,90,85,80,75,70,65};
    private float horizontalSwipe = 240f;
    private float verticalSwipe = 210f;
    private float horizontalFire = 100f;
    private float verticalFire = 120f;

    private final List<TargetDot> targets = new ArrayList<>();
    private final List<HudButton> hud = new ArrayList<>();
    private HudButton joystick;

    private long sessionStartNs;
    private long lastFrameNs;
    private long lastAutoShotNs;
    private long reactionShownNs;
    private long reactionDelayUntilNs;
    private boolean reactionVisible = false;

    private int shots = 0;
    private int hits = 0;
    private double reactionTotalMs = 0;
    private int reactionHits = 0;
    private double trackingFireMs = 0;
    private double trackingOnTargetMs = 0;

    private int firePointer = -1;
    private int adsPointer = -1;
    private int aimPointer = -1;
    private int joystickPointer = -1;
    private int hudEditPointer = -1;
    private HudButton draggedButton = null;
    private float aimLastX, aimLastY;
    private float joyCenterX, joyCenterY, joyKnobX, joyKnobY;
    private boolean firing = false;
    private boolean adsHeld = false;
    private float strafe = 0f;

    private float crossX, crossY;
    private float recoilDrift = 0f;
    private String toastText = "";
    private long toastUntilNs = 0;

    private final RectF startRect = new RectF();
    private final RectF hudRect = new RectF();
    private final RectF sensRect = new RectF();
    private final RectF durationRect = new RectF();
    private final RectF scopeRect = new RectF();
    private final RectF backRect = new RectF();
    private final RectF resetRect = new RectF();

    public AimTrainerView(Context context) {
        super(context);
        setBackgroundColor(BG);
        setFocusable(true);
        prefs = context.getSharedPreferences("clawaim", Context.MODE_PRIVATE);
        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        initHud();
        loadPrefs();
    }

    private void initHud() {
        hud.add(new HudButton("FIRE", 0.155f, 0.225f, 0.075f, HudType.FIRE));
        hud.add(new HudButton("ADS", 0.805f, 0.205f, 0.052f, HudType.ADS));
        hud.add(new HudButton("LEAN L", 0.770f, 0.095f, 0.045f, HudType.LEAN_L));
        hud.add(new HudButton("LEAN R", 0.855f, 0.095f, 0.045f, HudType.LEAN_R));
        hud.add(new HudButton("JUMP", 0.915f, 0.240f, 0.050f, HudType.JUMP));
        hud.add(new HudButton("CROUCH", 0.915f, 0.400f, 0.050f, HudType.CROUCH));
        hud.add(new HudButton("PRONE", 0.900f, 0.565f, 0.045f, HudType.PRONE));
        hud.add(new HudButton("RELOAD", 0.705f, 0.680f, 0.045f, HudType.RELOAD));
        joystick = new HudButton("MOVE", 0.150f, 0.755f, 0.082f, HudType.JOYSTICK);
    }

    private void loadPrefs() {
        horizontalSwipe = prefs.getFloat("horizontalSwipe", 240f);
        verticalSwipe = prefs.getFloat("verticalSwipe", 210f);
        horizontalFire = prefs.getFloat("horizontalFire", 100f);
        verticalFire = prefs.getFloat("verticalFire", 120f);
        for (int i = 0; i < cameraSens.length; i++) {
            cameraSens[i] = prefs.getFloat("cam" + i, cameraSens[i]);
            firingSens[i] = prefs.getFloat("fire" + i, firingSens[i]);
        }
        for (HudButton b : allHud()) {
            b.nx = prefs.getFloat("hud_" + b.type + "_x", b.nx);
            b.ny = prefs.getFloat("hud_" + b.type + "_y", b.ny);
            b.nr = prefs.getFloat("hud_" + b.type + "_r", b.nr);
        }
    }

    private List<HudButton> allHud() {
        List<HudButton> all = new ArrayList<>(hud);
        all.add(joystick);
        return all;
    }

    private void savePrefs() {
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("horizontalSwipe", horizontalSwipe);
        e.putFloat("verticalSwipe", verticalSwipe);
        e.putFloat("horizontalFire", horizontalFire);
        e.putFloat("verticalFire", verticalFire);
        for (int i = 0; i < cameraSens.length; i++) {
            e.putFloat("cam" + i, cameraSens[i]);
            e.putFloat("fire" + i, firingSens[i]);
        }
        for (HudButton b : allHud()) {
            e.putFloat("hud_" + b.type + "_x", b.nx);
            e.putFloat("hud_" + b.type + "_y", b.ny);
            e.putFloat("hud_" + b.type + "_r", b.nr);
        }
        e.apply();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        crossX = w / 2f;
        crossY = h / 2f;
        updateHudPixels();
    }

    private void updateHudPixels() {
        float h = Math.max(1, getHeight());
        for (HudButton b : allHud()) {
            b.x = b.nx * getWidth();
            b.y = b.ny * getHeight();
            b.r = b.nr * h;
        }
        joyCenterX = joystick.x;
        joyCenterY = joystick.y;
        if (joystickPointer < 0) {
            joyKnobX = joyCenterX;
            joyKnobY = joyCenterY;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now = System.nanoTime();
        if (lastFrameNs == 0) lastFrameNs = now;
        float dt = Math.min(0.05f, (now - lastFrameNs) / 1_000_000_000f);
        lastFrameNs = now;

        if (screen == Screen.TRAINING) {
            updateTraining(now, dt);
            drawTraining(c, now);
        } else if (screen == Screen.HUD_EDIT) {
            drawTrainingBackdrop(c);
            drawHud(c, true);
            drawTopTitle(c, "HUD EDITOR — DRAG BUTTONS TO MATCH YOUR DELTA FORCE LAYOUT");
            drawBottomAction(c, "SAVE & BACK");
        } else if (screen == Screen.SENSITIVITY) {
            drawSensitivity(c);
        } else {
            drawHome(c);
        }

        if (now < toastUntilNs && !toastText.isEmpty()) {
            p.setColor(Color.argb(220, 0, 0, 0));
            RectF r = new RectF(getWidth() * .36f, getHeight() * .82f, getWidth() * .64f, getHeight() * .90f);
            c.drawRoundRect(r, 18, 18, p);
            drawCentered(c, toastText, r.centerX(), r.centerY() + dp(5), dp(17), TEXT);
        }

        postInvalidateOnAnimation();
    }

    private void drawHome(Canvas c) {
        p.setColor(BG); c.drawRect(0,0,getWidth(),getHeight(),p);
        drawText(c, "CLAWAIM", getWidth()*.045f, getHeight()*.10f, dp(32), TEXT, true);
        drawText(c, "4-FINGER AIM TRAINER", getWidth()*.045f, getHeight()*.145f, dp(18), ACCENT, true);
        drawText(c, "Built around your Hold-ADS four-finger layout and the smoother sensitivity curve.",
                getWidth()*.045f, getHeight()*.205f, dp(14), MUTED, false);

        float left = getWidth()*.045f;
        float top = getHeight()*.28f;
        float cardW = getWidth()*.16f;
        float cardH = getHeight()*.25f;
        float gap = getWidth()*.012f;
        Mode[] modes = Mode.values();
        String[] names = {"FLICK", "TRACKING", "SWITCH", "REACTION", "RECOIL"};
        String[] desc = {"Fast target acquisition", "Keep crosshair locked", "Transfer between targets", "First-shot speed", "Pull-down control"};
        for (int i=0;i<modes.length;i++) {
            RectF r = new RectF(left+i*(cardW+gap), top, left+i*(cardW+gap)+cardW, top+cardH);
            p.setColor(mode==modes[i] ? PANEL2 : PANEL); c.drawRoundRect(r, 20,20,p);
            if (mode==modes[i]) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(ACCENT); c.drawRoundRect(r,20,20,p); p.setStyle(Paint.Style.FILL); }
            drawCentered(c, names[i], r.centerX(), r.top+cardH*.42f, dp(17), TEXT);
            drawCentered(c, desc[i], r.centerX(), r.top+cardH*.68f, dp(11), MUTED);
        }

        float y = getHeight()*.62f;
        durationRect.set(getWidth()*.045f,y,getWidth()*.255f,y+getHeight()*.085f);
        scopeRect.set(getWidth()*.275f,y,getWidth()*.485f,y+getHeight()*.085f);
        hudRect.set(getWidth()*.505f,y,getWidth()*.705f,y+getHeight()*.085f);
        sensRect.set(getWidth()*.725f,y,getWidth()*.925f,y+getHeight()*.085f);
        drawAction(c,durationRect,"SESSION  " + sessionSeconds + "s",false);
        drawAction(c,scopeRect,"SCOPE  " + scopeName(),false);
        drawAction(c,hudRect,"HUD EDIT",false);
        drawAction(c,sensRect,"SENSITIVITY",false);

        startRect.set(getWidth()*.36f,getHeight()*.77f,getWidth()*.64f,getHeight()*.90f);
        drawAction(c,startRect,"START TRAINING",true);
        drawText(c, "Tip: keep the right-middle of the screen clear for your aiming thumb.",
                getWidth()*.045f,getHeight()*.95f,dp(12),MUTED,false);
    }

    private void drawTrainingBackdrop(Canvas c) {
        p.setColor(BG); c.drawRect(0,0,getWidth(),getHeight(),p);
        p.setColor(Color.rgb(15,23,31));
        for (int i=1;i<10;i++) c.drawLine(i*getWidth()/10f, 0, i*getWidth()/10f, getHeight(), p);
        for (int i=1;i<6;i++) c.drawLine(0, i*getHeight()/6f, getWidth(), i*getHeight()/6f, p);
        drawCrosshair(c);
    }

    private void drawTraining(Canvas c, long now) {
        drawTrainingBackdrop(c);
        for (TargetDot t : targets) drawTarget(c,t);
        drawCrosshair(c);
        drawHud(c,false);

        float elapsed = (now-sessionStartNs)/1_000_000_000f;
        int remain = Math.max(0, sessionSeconds - (int)elapsed);
        drawText(c, modeName()+"   " + scopeName(), getWidth()*.02f, getHeight()*.055f, dp(14), TEXT, true);
        drawCentered(c, String.format(Locale.US,"%02d",remain), getWidth()*.50f, getHeight()*.055f, dp(20), TEXT);
        String stats = "HITS " + hits + "   SHOTS " + shots + "   ACC " + accuracyText();
        drawText(c, stats, getWidth()*.67f, getHeight()*.055f, dp(13), TEXT, true);
        drawText(c, "PAUSE", getWidth()*.925f, getHeight()*.055f, dp(12), ACCENT, true);

        if (mode==Mode.TRACKING) {
            String s = trackingFireMs <= 0 ? "TRACK 0%" : String.format(Locale.US,"TRACK %.0f%%",100*trackingOnTargetMs/trackingFireMs);
            drawText(c,s,getWidth()*.02f,getHeight()*.10f,dp(12),ACCENT,true);
        } else if (mode==Mode.REACTION && reactionHits>0) {
            drawText(c,String.format(Locale.US,"AVG REACTION %.0f ms",reactionTotalMs/reactionHits),getWidth()*.02f,getHeight()*.10f,dp(12),ACCENT,true);
        }
    }

    private void drawHud(Canvas c, boolean edit) {
        for (HudButton b : hud) drawHudButton(c,b,edit);
        drawJoystick(c,edit);
        if (edit) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(110,64,219,169));
            RectF safe = new RectF(getWidth()*.42f,getHeight()*.16f,getWidth()*.76f,getHeight()*.78f);
            c.drawRoundRect(safe,24,24,p); p.setStyle(Paint.Style.FILL);
            drawCentered(c,"KEEP THIS AIMING ZONE CLEAR",safe.centerX(),safe.centerY(),dp(13),Color.argb(180,235,242,246));
        }
    }

    private void drawHudButton(Canvas c, HudButton b, boolean edit) {
        boolean active = (b.type==HudType.FIRE && firing) || (b.type==HudType.ADS && adsHeld) || b==draggedButton;
        p.setColor(active ? Color.argb(215,64,219,169) : Color.argb(edit?145:105,56,69,79));
        c.drawCircle(b.x,b.y,b.r,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(Color.argb(190,205,220,228)); c.drawCircle(b.x,b.y,b.r,p); p.setStyle(Paint.Style.FILL);
        drawCentered(c,b.label,b.x,b.y+dp(4),Math.max(dp(8),b.r*.28f),TEXT);
    }

    private void drawJoystick(Canvas c, boolean edit) {
        p.setColor(Color.argb(edit?120:80,70,84,94)); c.drawCircle(joyCenterX,joyCenterY,joystick.r,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(130,205,220,228)); c.drawCircle(joyCenterX,joyCenterY,joystick.r,p); p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(155,150,166,176)); c.drawCircle(joyKnobX,joyKnobY,joystick.r*.42f,p);
        drawCentered(c,"MOVE",joyCenterX,joyCenterY-joystick.r*1.18f,dp(10),MUTED);
    }

    private void drawSensitivity(Canvas c) {
        p.setColor(BG); c.drawRect(0,0,getWidth(),getHeight(),p);
        drawTopTitle(c,"SENSITIVITY — DELTA-STYLE SMOOTH CURVE");
        drawText(c,"Camera",getWidth()*.20f,getHeight()*.16f,dp(14),ACCENT,true);
        drawText(c,"Firing",getWidth()*.35f,getHeight()*.16f,dp(14),ACCENT,true);
        drawText(c,"− / +",getWidth()*.52f,getHeight()*.16f,dp(14),MUTED,true);

        float startY=getHeight()*.22f;
        float rowH=getHeight()*.052f;
        for (int i=0;i<13;i++) {
            float y=startY+i*rowH;
            if (y>getHeight()*.84f) break;
            drawText(c,scopeName(i),getWidth()*.07f,y,dp(12),TEXT,true);
            drawText(c,String.format(Locale.US,"%.0f",cameraSens[i]),getWidth()*.21f,y,dp(12),TEXT,false);
            drawText(c,String.format(Locale.US,"%.0f",firingSens[i]),getWidth()*.36f,y,dp(12),TEXT,false);
            drawSmallButton(c,getWidth()*.50f,y-dp(16),"−C");
            drawSmallButton(c,getWidth()*.56f,y-dp(16),"+C");
            drawSmallButton(c,getWidth()*.64f,y-dp(16),"−F");
            drawSmallButton(c,getWidth()*.70f,y-dp(16),"+F");
        }

        float x=getWidth()*.77f;
        float y=getHeight()*.23f;
        drawText(c,"GLOBAL",x,y,dp(15),ACCENT,true); y+=getHeight()*.07f;
        drawGlobalRow(c,"H Swipe",horizontalSwipe,x,y,0); y+=getHeight()*.085f;
        drawGlobalRow(c,"V Swipe",verticalSwipe,x,y,1); y+=getHeight()*.085f;
        drawGlobalRow(c,"H Fire",horizontalFire,x,y,2); y+=getHeight()*.085f;
        drawGlobalRow(c,"V Fire",verticalFire,x,y,3);
        drawText(c,"Defaults: Fixed turning, Hold ADS, Instant transition.",x,getHeight()*.70f,dp(11),MUTED,false);
        drawText(c,"Important: raw sensitivity numbers are a training preset; exact 1:1 game-engine scaling can vary.",x,getHeight()*.76f,dp(10),MUTED,false);

        resetRect.set(getWidth()*.76f,getHeight()*.83f,getWidth()*.88f,getHeight()*.91f);
        backRect.set(getWidth()*.89f,getHeight()*.83f,getWidth()*.98f,getHeight()*.91f);
        drawAction(c,resetRect,"RESET",false);
        drawAction(c,backRect,"SAVE",true);
    }

    private void drawGlobalRow(Canvas c,String name,float value,float x,float y,int idx) {
        drawText(c,name,x,y,dp(11),TEXT,true);
        drawText(c,String.format(Locale.US,"%.0f",value),x+getWidth()*.10f,y,dp(12),TEXT,false);
        drawSmallButton(c,x+getWidth()*.145f,y-dp(16),"−");
        drawSmallButton(c,x+getWidth()*.185f,y-dp(16),"+");
    }

    private void drawSmallButton(Canvas c,float x,float y,String text) {
        RectF r=new RectF(x,y,x+getWidth()*.045f,y+getHeight()*.042f);
        p.setColor(PANEL2); c.drawRoundRect(r,9,9,p); drawCentered(c,text,r.centerX(),r.centerY()+dp(4),dp(10),TEXT);
    }

    private void drawTopTitle(Canvas c,String title) {
        drawText(c,title,getWidth()*.04f,getHeight()*.08f,dp(18),TEXT,true);
        p.setColor(ACCENT); c.drawRect(getWidth()*.04f,getHeight()*.105f,getWidth()*.96f,getHeight()*.109f,p);
    }

    private void drawBottomAction(Canvas c,String label) {
        backRect.set(getWidth()*.79f,getHeight()*.87f,getWidth()*.96f,getHeight()*.95f);
        drawAction(c,backRect,label,true);
    }

    private void drawAction(Canvas c,RectF r,String label,boolean accent) {
        p.setColor(accent ? ACCENT : PANEL2); c.drawRoundRect(r,16,16,p);
        drawCentered(c,label,r.centerX(),r.centerY()+dp(5),dp(13),accent?Color.rgb(5,28,22):TEXT);
    }

    private void drawTarget(Canvas c, TargetDot t) {
        p.setColor(TARGET); c.drawCircle(t.x,t.y,t.r,p);
        p.setColor(Color.rgb(255,238,238)); c.drawCircle(t.x,t.y,t.r*.34f,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(TARGET_RING); c.drawCircle(t.x,t.y,t.r*1.16f,p); p.setStyle(Paint.Style.FILL);
    }

    private void drawCrosshair(Canvas c) {
        p.setColor(Color.WHITE); p.setStrokeWidth(dp(2));
        float g=dp(7), len=dp(13);
        c.drawLine(crossX-g-len,crossY,crossX-g,crossY,p);
        c.drawLine(crossX+g,crossY,crossX+g+len,crossY,p);
        c.drawLine(crossX,crossY-g-len,crossX,crossY-g,p);
        c.drawLine(crossX,crossY+g,crossX,crossY+g+len,p);
        c.drawCircle(crossX,crossY,dp(1.5f),p);
    }

    private void updateTraining(long now, float dt) {
        if ((now-sessionStartNs)/1_000_000_000f >= sessionSeconds) {
            showSummary();
            return;
        }

        if (mode==Mode.TRACKING || mode==Mode.SWITCHING) {
            for (TargetDot t:targets) {
                t.x += t.vx*dt; t.y += t.vy*dt;
                float margin=t.r*1.3f;
                if (t.x<margin || t.x>getWidth()-margin) { t.vx=-t.vx; t.x=clamp(t.x,margin,getWidth()-margin); }
                if (t.y<getHeight()*.15f+margin || t.y>getHeight()*.92f-margin) { t.vy=-t.vy; t.y=clamp(t.y,getHeight()*.15f+margin,getHeight()*.92f-margin); }
            }
        }

        if (joystickPointer>=0) shiftTargets(strafe*dt*getWidth()*.22f,0);

        if (mode==Mode.REACTION && !reactionVisible && now>=reactionDelayUntilNs) {
            spawnSingleTarget(); reactionVisible=true; reactionShownNs=now;
        }

        if (firing) {
            if (mode==Mode.TRACKING) {
                trackingFireMs += dt*1000.0;
                if (isAnyTargetOnCrosshair()) trackingOnTargetMs += dt*1000.0;
            } else {
                long interval=105_000_000L;
                if (now-lastAutoShotNs>=interval) { doShot(now); lastAutoShotNs=now; }
            }
            if (mode==Mode.RECOIL) {
                recoilDrift += dt*getHeight()*.22f;
                shiftTargets(0,dt*getHeight()*.22f);
            }
        }
    }

    private void startTraining() {
        screen=Screen.TRAINING;
        shots=hits=0; reactionTotalMs=0; reactionHits=0; trackingFireMs=trackingOnTargetMs=0;
        firing=false; adsHeld=false; recoilDrift=0; firePointer=adsPointer=aimPointer=joystickPointer=-1;
        sessionStartNs=System.nanoTime(); lastFrameNs=sessionStartNs; lastAutoShotNs=0;
        targets.clear();
        if (mode==Mode.SWITCHING) {
            for(int i=0;i<3;i++) targets.add(randomTarget(true));
        } else if (mode==Mode.REACTION) {
            reactionVisible=false; scheduleReaction(sessionStartNs);
        } else {
            spawnSingleTarget();
        }
    }

    private void showSummary() {
        String s;
        if (mode==Mode.TRACKING) {
            double pct=trackingFireMs<=0?0:100*trackingOnTargetMs/trackingFireMs;
            s=String.format(Locale.US,"Tracking %.0f%%",pct);
        } else if (mode==Mode.REACTION && reactionHits>0) {
            s=String.format(Locale.US,"Avg reaction %.0f ms",reactionTotalMs/reactionHits);
        } else {
            s="Accuracy "+accuracyText()+" • Hits "+hits;
        }
        screen=Screen.HOME;
        toast("Session complete — "+s,3800);
    }

    private void spawnSingleTarget() {
        targets.clear(); targets.add(randomTarget(mode==Mode.TRACKING));
    }

    private TargetDot randomTarget(boolean moving) {
        float r=getHeight()*(mode==Mode.TRACKING?.046f:.041f);
        float x=getWidth()*(.27f+rng.nextFloat()*.47f);
        float y=getHeight()*(.22f+rng.nextFloat()*.57f);
        float speed=getWidth()*(.07f+rng.nextFloat()*.055f);
        float ang=(float)(rng.nextDouble()*Math.PI*2);
        return new TargetDot(x,y,r,moving?(float)Math.cos(ang)*speed:0,moving?(float)Math.sin(ang)*speed:0);
    }

    private void scheduleReaction(long now) {
        reactionDelayUntilNs=now+(700+rng.nextInt(1300))*1_000_000L;
    }

    private void doShot(long now) {
        if (mode==Mode.REACTION && !reactionVisible) { shots++; return; }
        shots++;
        int hitIndex=findTargetOnCrosshair();
        if (hitIndex>=0) {
            hits++; haptic();
            if (mode==Mode.REACTION) {
                reactionTotalMs+=(now-reactionShownNs)/1_000_000.0; reactionHits++;
                targets.clear(); reactionVisible=false; scheduleReaction(now);
            } else if (mode==Mode.SWITCHING) {
                targets.set(hitIndex,randomTarget(true));
            } else if (mode==Mode.RECOIL) {
                // Keep one target so the drill rewards continuous correction.
            } else {
                spawnSingleTarget();
            }
        }
    }

    private int findTargetOnCrosshair() {
        for(int i=0;i<targets.size();i++) {
            TargetDot t=targets.get(i); float dx=t.x-crossX,dy=t.y-crossY;
            if(dx*dx+dy*dy<=t.r*t.r) return i;
        }
        return -1;
    }
    private boolean isAnyTargetOnCrosshair(){ return findTargetOnCrosshair()>=0; }

    private void shiftTargets(float dx,float dy) {
        for(TargetDot t:targets){ t.x+=dx; t.y+=dy; }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action=e.getActionMasked();
        int index=e.getActionIndex();
        int pid=e.getPointerId(index);
        float x=e.getX(index), y=e.getY(index);

        if (screen==Screen.HOME) return handleHomeTouch(e,action,index,x,y);
        if (screen==Screen.SENSITIVITY) return handleSensitivityTouch(e,action,index,x,y);
        if (screen==Screen.HUD_EDIT) return handleHudEditTouch(e,action,index,pid,x,y);

        if (screen==Screen.TRAINING) {
            if (action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
                if (x>getWidth()*.90f && y<getHeight()*.10f) { screen=Screen.HOME; firing=false; adsHeld=false; return true; }
                HudButton b=findHudAt(x,y);
                if (b!=null) {
                    if (b.type==HudType.FIRE && firePointer<0) { firePointer=pid; firing=true; lastAutoShotNs=0; doShot(System.nanoTime()); lastAutoShotNs=System.nanoTime(); }
                    else if (b.type==HudType.ADS && adsPointer<0) { adsPointer=pid; adsHeld=true; }
                    else { toast(b.label,500); }
                } else if (insideJoystick(x,y) && joystickPointer<0) {
                    joystickPointer=pid; updateJoystick(x,y);
                } else if (aimPointer<0) {
                    aimPointer=pid; aimLastX=x; aimLastY=y;
                }
            } else if (action==MotionEvent.ACTION_MOVE) {
                for(int i=0;i<e.getPointerCount();i++) {
                    int id=e.getPointerId(i); float px=e.getX(i),py=e.getY(i);
                    if(id==aimPointer) handleAimMove(px,py);
                    if(id==joystickPointer) updateJoystick(px,py);
                }
            } else if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
                if(pid==firePointer){firePointer=-1;firing=false;}
                if(pid==adsPointer){adsPointer=-1;adsHeld=false;}
                if(pid==aimPointer){aimPointer=-1;}
                if(pid==joystickPointer){joystickPointer=-1;strafe=0;joyKnobX=joyCenterX;joyKnobY=joyCenterY;}
                if(action==MotionEvent.ACTION_CANCEL){firePointer=adsPointer=aimPointer=joystickPointer=-1;firing=false;adsHeld=false;strafe=0;}
            }
            return true;
        }
        return true;
    }

    private boolean handleHomeTouch(MotionEvent e,int action,int index,float x,float y) {
        if(action!=MotionEvent.ACTION_UP) return true;
        float left=getWidth()*.045f, top=getHeight()*.28f, cardW=getWidth()*.16f, cardH=getHeight()*.25f, gap=getWidth()*.012f;
        for(int i=0;i<5;i++) {
            RectF r=new RectF(left+i*(cardW+gap),top,left+i*(cardW+gap)+cardW,top+cardH);
            if(r.contains(x,y)){ mode=Mode.values()[i]; return true; }
        }
        if(startRect.contains(x,y)){startTraining();return true;}
        if(hudRect.contains(x,y)){screen=Screen.HUD_EDIT;return true;}
        if(sensRect.contains(x,y)){screen=Screen.SENSITIVITY;return true;}
        if(durationRect.contains(x,y)){sessionSeconds=sessionSeconds==30?60:sessionSeconds==60?120:30;return true;}
        if(scopeRect.contains(x,y)){selectedScope++;if(selectedScope>6)selectedScope=0;return true;}
        return true;
    }

    private boolean handleHudEditTouch(MotionEvent e,int action,int index,int pid,float x,float y) {
        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
            if(backRect.contains(x,y)){savePrefs();screen=Screen.HOME;toast("HUD saved",1200);return true;}
            HudButton b=findHudAtIncludingJoystick(x,y);
            if(b!=null && hudEditPointer<0){hudEditPointer=pid;draggedButton=b;}
        } else if(action==MotionEvent.ACTION_MOVE && draggedButton!=null) {
            for(int i=0;i<e.getPointerCount();i++) if(e.getPointerId(i)==hudEditPointer){
                draggedButton.x=clamp(e.getX(i),draggedButton.r,getWidth()-draggedButton.r);
                draggedButton.y=clamp(e.getY(i),draggedButton.r,getHeight()-draggedButton.r);
                draggedButton.nx=draggedButton.x/getWidth(); draggedButton.ny=draggedButton.y/getHeight();
                if(draggedButton==joystick){joyCenterX=draggedButton.x;joyCenterY=draggedButton.y;joyKnobX=joyCenterX;joyKnobY=joyCenterY;}
            }
        } else if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
            if(pid==hudEditPointer || action==MotionEvent.ACTION_CANCEL){hudEditPointer=-1;draggedButton=null;}
        }
        return true;
    }

    private boolean handleSensitivityTouch(MotionEvent e,int action,int index,float x,float y) {
        if(action!=MotionEvent.ACTION_UP) return true;
        if(backRect.contains(x,y)){savePrefs();screen=Screen.HOME;toast("Sensitivity saved",1200);return true;}
        if(resetRect.contains(x,y)){resetSensitivity();toast("Sensitivity reset",1200);return true;}

        float startY=getHeight()*.22f,rowH=getHeight()*.052f;
        int row=Math.round((y-startY)/rowH);
        if(row>=0 && row<13 && Math.abs(y-(startY+row*rowH))<rowH*.48f) {
            if(x>getWidth()*.49f && x<getWidth()*.55f) cameraSens[row]=clamp(cameraSens[row]-5,20,300);
            else if(x>getWidth()*.55f && x<getWidth()*.62f) cameraSens[row]=clamp(cameraSens[row]+5,20,300);
            else if(x>getWidth()*.63f && x<getWidth()*.69f) firingSens[row]=clamp(firingSens[row]-5,20,300);
            else if(x>getWidth()*.69f && x<getWidth()*.76f) firingSens[row]=clamp(firingSens[row]+5,20,300);
            return true;
        }
        // Global minus/plus zones.
        float baseY=getHeight()*.30f, step=getHeight()*.085f;
        for(int i=0;i<4;i++){
            float yy=baseY+i*step;
            if(Math.abs(y-yy)<step*.42f){
                if(x>getWidth()*.905f && x<getWidth()*.95f) adjustGlobal(i,-5);
                else if(x>getWidth()*.95f) adjustGlobal(i,5);
            }
        }
        return true;
    }

    private void adjustGlobal(int i,float d){
        if(i==0)horizontalSwipe=clamp(horizontalSwipe+d,50,300);
        if(i==1)verticalSwipe=clamp(verticalSwipe+d,50,300);
        if(i==2)horizontalFire=clamp(horizontalFire+d,50,300);
        if(i==3)verticalFire=clamp(verticalFire+d,50,300);
    }

    private void resetSensitivity(){
        float[] c={190,150,140,125,110,100,90,85,80,75,70,65,60};
        float[] f={180,160,145,130,115,105,95,90,85,80,75,70,65};
        System.arraycopy(c,0,cameraSens,0,c.length); System.arraycopy(f,0,firingSens,0,f.length);
        horizontalSwipe=240;verticalSwipe=210;horizontalFire=100;verticalFire=120;
    }

    private void handleAimMove(float x,float y) {
        float dx=x-aimLastX,dy=y-aimLastY; aimLastX=x;aimLastY=y;
        int idx=Math.max(0,Math.min(selectedScope,12));
        float sens=(firing?firingSens[idx]:cameraSens[idx]);
        float hx=firing?horizontalFire/100f:horizontalSwipe/240f;
        float vy=firing?verticalFire/120f:verticalSwipe/210f;
        float factor=1.45f*(sens/150f);
        shiftTargets(-dx*factor*hx,-dy*factor*vy);
    }

    private void updateJoystick(float x,float y) {
        float dx=x-joyCenterX,dy=y-joyCenterY;
        float max=joystick.r*.72f;
        float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>max){dx*=max/len;dy*=max/len;}
        joyKnobX=joyCenterX+dx;joyKnobY=joyCenterY+dy;
        strafe=clamp(dx/max,-1,1);
    }

    private boolean insideJoystick(float x,float y){float dx=x-joyCenterX,dy=y-joyCenterY;return dx*dx+dy*dy<=joystick.r*joystick.r;}
    private HudButton findHudAt(float x,float y){for(HudButton b:hud)if(b.hit(x,y))return b;return null;}
    private HudButton findHudAtIncludingJoystick(float x,float y){HudButton b=findHudAt(x,y);if(b!=null)return b;return joystick.hit(x,y)?joystick:null;}

    private String modeName(){return switch(mode){case FLICK->"FLICK";case TRACKING->"TRACKING";case SWITCHING->"TARGET SWITCH";case REACTION->"REACTION";case RECOIL->"RECOIL";};}
    private String scopeName(){return scopeName(selectedScope);}
    private String scopeName(int i){return i==0?"HIP":i==1?"1x / RED DOT":i+"x";}
    private String accuracyText(){return shots==0?"0%":String.format(Locale.US,"%.0f%%",100.0*hits/shots);}

    private void toast(String s,long ms){toastText=s;toastUntilNs=System.nanoTime()+ms*1_000_000L;}
    private void haptic(){
        if(vibrator==null || !vibrator.hasVibrator())return;
        if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(18);
    }

    private void drawText(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?android.graphics.Typeface.DEFAULT_BOLD:android.graphics.Typeface.DEFAULT);p.setTextAlign(Paint.Align.LEFT);c.drawText(s,x,y,p);}
    private void drawCentered(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private enum HudType { FIRE, ADS, LEAN_L, LEAN_R, JUMP, CROUCH, PRONE, RELOAD, JOYSTICK }
    private static class HudButton {
        String label; float nx,ny,nr,x,y,r; HudType type;
        HudButton(String label,float nx,float ny,float nr,HudType type){this.label=label;this.nx=nx;this.ny=ny;this.nr=nr;this.type=type;}
        boolean hit(float px,float py){float dx=px-x,dy=py-y;return dx*dx+dy*dy<=r*r;}
    }
    private static class TargetDot {
        float x,y,r,vx,vy;
        TargetDot(float x,float y,float r,float vx,float vy){this.x=x;this.y=y;this.r=r;this.vx=vx;this.vy=vy;}
    }
}
