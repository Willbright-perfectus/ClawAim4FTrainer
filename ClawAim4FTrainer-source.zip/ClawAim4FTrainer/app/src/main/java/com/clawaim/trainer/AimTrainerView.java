package com.clawaim.trainer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class AimTrainerView extends View {
    private enum Screen { HOME, TRAINING, HUD_EDIT, SENSITIVITY }
    private enum Mode { FLICK, TRACKING, SWITCHING, REACTION, RECOIL, STATIC_AIM }

    private static final int BG = Color.rgb(11, 17, 23);
    private static final int PANEL = Color.rgb(24, 34, 43);
    private static final int PANEL2 = Color.rgb(31, 45, 56);
    private static final int TEXT = Color.rgb(235, 242, 246);
    private static final int MUTED = Color.rgb(145, 164, 176);
    private static final int ACCENT = Color.rgb(64, 219, 169);
    private static final int TARGET = Color.rgb(255, 83, 83);
    private static final int TARGET_RING = Color.rgb(255, 183, 74);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final SharedPreferences prefs;
    private final Bitmap logoBitmap;

    private Screen screen = Screen.HOME;
    private Mode mode = Mode.FLICK;
    private int sessionSeconds = 60;
    private int selectedScope = 1; // 0 hip, 1=1x, 2=2x ... 12

    private final float[] cameraSens = {190,150,140,125,110,100,90,85,80,75,70,65,60};
    private final float[] firingSens = {180,160,145,130,115,105,95,90,85,80,75,70,65};
    private float horizontalSwipe = 240f;
    private float verticalSwipe = 210f;
    private float horizontalFire = 100f;
    private float verticalFire = 120f;
    private float targetScale = 1.0f;

    private final List<TargetDot> targets = new ArrayList<>();
    private final List<HudButton> hud = new ArrayList<>();
    private HudButton joystick;

    private long sessionStartNs;
    private long lastFrameNs;
    private long lastAutoShotNs;
    private long reactionShownNs;
    private long reactionDelayUntilNs;
    private boolean reactionVisible = false;

    private int shots = 0;
    private int hits = 0;
    private double reactionTotalMs = 0;
    private int reactionHits = 0;
    private double trackingFireMs = 0;
    private double trackingOnTargetMs = 0;

    private int firePointer = -1;
    private int adsPointer = -1;
    private int leanLeftPointer = -1;
    private int leanRightPointer = -1;
    private int aimPointer = -1;
    private int joystickPointer = -1;
    private int hudEditPointer = -1;
    private HudButton draggedButton = null;
    private float aimLastX, aimLastY;
    private float joyCenterX, joyCenterY, joyKnobX, joyKnobY;
    private boolean firing = false;
    private boolean adsHeld = false;
    private int leanDirection = 0; // -1 left, +1 right
    private float strafe = 0f;
    private float forward = 0f;
    private float leanVisual = 0f;
    private float adsZoom = 1f;
    private float stanceOffset = 0f;
    private float jumpOffset = 0f;
    private float jumpVelocity = 0f;
    private boolean airborne = false;
    private float playerLateral = 0f;
    private float playerForward = 0f;

    private float crossX, crossY;
    // FPS camera state. The crosshair remains at screen center like Delta Force;
    // swiping rotates the 3D-style scene underneath it.
    private float cameraYaw = 0f;
    private float cameraPitch = 0f;
    private float recoilDrift = 0f;
    private int magazineSize = 45;
    private int ammo = 45;
    private boolean reloading = false;
    private long reloadFinishNs = 0;
    private static final long SHOT_INTERVAL_NS = 75_000_000L; // 800 rpm
    private static final long RELOAD_NS = 2_640_000_000L;
    private int displayedFps = 0;
    private int fpsFrames = 0;
    private long fpsWindowNs = 0;
    private float hudOpacity = 0.70f;
    private HudButton selectedHudButton = null;
    private String toastText = "";
    private long toastUntilNs = 0;

    private final RectF startRect = new RectF();
    private final RectF hudRect = new RectF();
    private final RectF sensRect = new RectF();
    private final RectF durationRect = new RectF();
    private final RectF scopeRect = new RectF();
    private final RectF backRect = new RectF();
    private final RectF saveRect = new RectF();
    private final RectF resetRect = new RectF();

    // Temporary editor snapshots so BACK/CANCEL truly discards changes.
    private final float[] snapCamera = new float[13];
    private final float[] snapFiring = new float[13];
    private float snapHSwipe, snapVSwipe, snapHFire, snapVFire, snapHudOpacity, snapTargetScale;
    private final List<float[]> snapHud = new ArrayList<>();

    public AimTrainerView(Context context) {
        super(context);
        setBackgroundColor(BG);
        setFocusable(true);
        prefs = context.getSharedPreferences("clawaim", Context.MODE_PRIVATE);
        logoBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.clawaim_logo);
        initHud();
        loadPrefs();
    }

    private void initHud() {
        // Delta Force-inspired four-finger preset matching the supplied HUD:
        // left index FIRE, left thumb MOVE, right thumb aim zone, right index actions.
        hud.add(new HudButton("FIRE", 0.145f, 0.225f, 0.083f, HudType.FIRE));
        hud.add(new HudButton("ADS", 0.805f, 0.300f, 0.050f, HudType.ADS));
        hud.add(new HudButton("LEAN L", 0.835f, 0.085f, 0.043f, HudType.LEAN_L));
        hud.add(new HudButton("LEAN R", 0.915f, 0.085f, 0.043f, HudType.LEAN_R));
        hud.add(new HudButton("JUMP", 0.920f, 0.205f, 0.047f, HudType.JUMP));
        hud.add(new HudButton("CROUCH", 0.875f, 0.515f, 0.046f, HudType.CROUCH));
        hud.add(new HudButton("PRONE", 0.775f, 0.655f, 0.041f, HudType.PRONE));
        hud.add(new HudButton("RELOAD", 0.650f, 0.775f, 0.043f, HudType.RELOAD));
        hud.add(new HudButton("MELEE", 0.765f, 0.790f, 0.040f, HudType.MELEE));
        joystick = new HudButton("MOVE", 0.125f, 0.705f, 0.078f, HudType.JOYSTICK);
    }

    private void loadPrefs() {
        horizontalSwipe = prefs.getFloat("horizontalSwipe", 240f);
        verticalSwipe = prefs.getFloat("verticalSwipe", 210f);
        horizontalFire = prefs.getFloat("horizontalFire", 100f);
        verticalFire = prefs.getFloat("verticalFire", 120f);
        hudOpacity = prefs.getFloat("hudOpacity", 0.70f);
        targetScale = prefs.getFloat("targetScale", 1.0f);
        for (int i = 0; i < cameraSens.length; i++) {
            cameraSens[i] = prefs.getFloat("cam" + i, cameraSens[i]);
            firingSens[i] = prefs.getFloat("fire" + i, firingSens[i]);
        }
        for (HudButton b : allHud()) {
            b.nx = prefs.getFloat("hud_" + b.type + "_x", b.nx);
            b.ny = prefs.getFloat("hud_" + b.type + "_y", b.ny);
            b.nr = prefs.getFloat("hud_" + b.type + "_r", b.nr);
        }
    }

    private List<HudButton> allHud() {
        List<HudButton> all = new ArrayList<>(hud);
        all.add(joystick);
        return all;
    }

    private void savePrefs() {
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("horizontalSwipe", horizontalSwipe);
        e.putFloat("verticalSwipe", verticalSwipe);
        e.putFloat("horizontalFire", horizontalFire);
        e.putFloat("verticalFire", verticalFire);
        e.putFloat("hudOpacity", hudOpacity);
        e.putFloat("targetScale", targetScale);
        for (int i = 0; i < cameraSens.length; i++) {
            e.putFloat("cam" + i, cameraSens[i]);
            e.putFloat("fire" + i, firingSens[i]);
        }
        for (HudButton b : allHud()) {
            e.putFloat("hud_" + b.type + "_x", b.nx);
            e.putFloat("hud_" + b.type + "_y", b.ny);
            e.putFloat("hud_" + b.type + "_r", b.nr);
        }
        e.apply();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        crossX = w / 2f;
        crossY = h / 2f;
        updateHudPixels();
    }

    private void updateHudPixels() {
        float h = Math.max(1, getHeight());
        for (HudButton b : allHud()) {
            b.x = b.nx * getWidth();
            b.y = b.ny * getHeight();
            b.r = b.nr * h;
        }
        joyCenterX = joystick.x;
        joyCenterY = joystick.y;
        if (joystickPointer < 0) {
            joyKnobX = joyCenterX;
            joyKnobY = joyCenterY;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now = System.nanoTime();
        if (lastFrameNs == 0) lastFrameNs = now;
        float dt = Math.min(0.05f, (now - lastFrameNs) / 1_000_000_000f);
        lastFrameNs = now;
        if (fpsWindowNs == 0) fpsWindowNs = now;
        fpsFrames++;
        if (now - fpsWindowNs >= 500_000_000L) {
            displayedFps = Math.round(fpsFrames * 1_000_000_000f / (now - fpsWindowNs));
            fpsFrames = 0; fpsWindowNs = now;
        }

        if (screen == Screen.TRAINING) {
            updateTraining(now, dt);
            drawTraining(c, now);
        } else if (screen == Screen.HUD_EDIT) {
            drawTrainingBackdrop(c);
            drawHud(c, true);
            drawTopTitle(c, "HUD EDITOR — DRAG BUTTONS TO MATCH YOUR DELTA FORCE LAYOUT");
            drawBottomAction(c, "SAVE & BACK");
            drawHudEditControls(c);
        } else if (screen == Screen.SENSITIVITY) {
            drawSensitivity(c);
        } else {
            drawHome(c);
        }

        if (now < toastUntilNs && !toastText.isEmpty()) {
            p.setColor(Color.argb(220, 0, 0, 0));
            RectF r = new RectF(getWidth() * .36f, getHeight() * .82f, getWidth() * .64f, getHeight() * .90f);
            c.drawRoundRect(r, 18, 18, p);
            drawCentered(c, toastText, r.centerX(), r.centerY() + dp(5), dp(17), TEXT);
        }

        postInvalidateOnAnimation();
    }

    private void drawHome(Canvas c) {
        p.setColor(BG); c.drawRect(0,0,getWidth(),getHeight(),p);
        drawText(c, "CLAWAIM", getWidth()*.045f, getHeight()*.10f, dp(32), TEXT, true);
        drawText(c, "4-FINGER AIM TRAINER", getWidth()*.045f, getHeight()*.145f, dp(18), ACCENT, true);
        drawText(c, "Built around your Hold-ADS four-finger layout and the smoother sensitivity curve.",
                getWidth()*.045f, getHeight()*.205f, dp(14), MUTED, false);

        float left = getWidth()*.045f;
        float top = getHeight()*.28f;
        float cardW = getWidth()*.135f;
        float cardH = getHeight()*.25f;
        float gap = getWidth()*.012f;
        Mode[] modes = Mode.values();
        String[] names = {"FLICK", "TRACKING", "SWITCH", "REACTION", "RECOIL", "STATIC AIM"};
        String[] desc = {"Fast target acquisition", "Keep crosshair locked", "Transfer between targets", "First-shot speed", "Pull-down control", "Target stays still; move view"};
        for (int i=0;i<modes.length;i++) {
            RectF r = new RectF(left+i*(cardW+gap), top, left+i*(cardW+gap)+cardW, top+cardH);
            p.setColor(mode==modes[i] ? PANEL2 : PANEL); c.drawRoundRect(r, 20,20,p);
            if (mode==modes[i]) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(ACCENT); c.drawRoundRect(r,20,20,p); p.setStyle(Paint.Style.FILL); }
            drawCentered(c, names[i], r.centerX(), r.top+cardH*.42f, dp(17), TEXT);
            drawCentered(c, desc[i], r.centerX(), r.top+cardH*.68f, dp(11), MUTED);
        }

        if (logoBitmap != null) {
            float lw=getHeight()*.18f;
            RectF lr=new RectF(getWidth()-lw-getWidth()*.025f,getHeight()*.035f,getWidth()-getWidth()*.025f,getHeight()*.035f+lw);
            c.drawBitmap(logoBitmap,null,lr,p);
        }
        drawText(c,"M4A1 TRAINER   31 DMG   800 RPM   45 RDS   CONTROL 76   STABILITY 65   ACCURACY 63",
                getWidth()*.045f,getHeight()*.585f,dp(11),MUTED,true);

        float y = getHeight()*.62f;
        durationRect.set(getWidth()*.045f,y,getWidth()*.255f,y+getHeight()*.085f);
        scopeRect.set(getWidth()*.275f,y,getWidth()*.485f,y+getHeight()*.085f);
        hudRect.set(getWidth()*.505f,y,getWidth()*.705f,y+getHeight()*.085f);
        sensRect.set(getWidth()*.725f,y,getWidth()*.925f,y+getHeight()*.085f);
        drawAction(c,durationRect,"SESSION  " + sessionSeconds + "s",false);
        drawAction(c,scopeRect,"SCOPE  " + scopeName(),false);
        drawAction(c,hudRect,"HUD EDIT",false);
        drawAction(c,sensRect,"SENSITIVITY",false);

        startRect.set(getWidth()*.36f,getHeight()*.77f,getWidth()*.64f,getHeight()*.90f);
        drawAction(c,startRect,"START TRAINING",true);
        drawText(c, "Tip: keep the right-middle of the screen clear for your aiming thumb.",
                getWidth()*.045f,getHeight()*.95f,dp(12),MUTED,false);
    }

    private void drawTrainingBackdrop(Canvas c) {
        // REAL procedural 3D room: no flat background image. Every wall/floor/ceiling
        // panel is projected from world-space into the current camera view.
        p.setColor(Color.rgb(8, 11, 14));
        c.drawRect(0, 0, getWidth(), getHeight(), p);

        // Back wall first (furthest geometry).
        drawWallBack(c, 31f);

        // Side walls, ceiling and floor are broken into panels so perspective remains
        // convincing while the player turns, strafes, jumps, crouches and moves.
        for (float z = 30f; z >= -1f; z -= 2f) {
            float z0 = z - 2f;
            int band = (((int) z) / 2) & 1;
            int floorCol = band == 0 ? Color.rgb(48, 53, 57) : Color.rgb(42, 47, 51);
            int wallCol = band == 0 ? Color.rgb(43, 47, 50) : Color.rgb(37, 41, 44);
            int ceilCol = band == 0 ? Color.rgb(30, 34, 38) : Color.rgb(25, 29, 33);

            // Floor tiles across room width.
            for (float x = -9f; x < 9f; x += 3f) {
                drawQuad3D(c, floorCol,
                        x, 0f, z0, x + 3f, 0f, z0,
                        x + 3f, 0f, z, x, 0f, z);
            }
            // Ceiling panels.
            for (float x = -9f; x < 9f; x += 3f) {
                drawQuad3D(c, ceilCol,
                        x, 5.3f, z, x + 3f, 5.3f, z,
                        x + 3f, 5.3f, z0, x, 5.3f, z0);
            }
            // Left / right wall panels.
            drawQuad3D(c, wallCol,
                    -9f, 0f, z, -9f, 5.3f, z,
                    -9f, 5.3f, z0, -9f, 0f, z0);
            drawQuad3D(c, wallCol,
                    9f, 0f, z0, 9f, 5.3f, z0,
                    9f, 5.3f, z, 9f, 0f, z);

            // Yellow/black hazard bands at intervals.
            if (((int) z) % 8 == 0) {
                drawQuad3D(c, Color.rgb(178, 137, 38),
                        -8.95f, .12f, z0, -8.95f, .32f, z0,
                        -8.95f, .32f, z, -8.95f, .12f, z);
                drawQuad3D(c, Color.rgb(178, 137, 38),
                        8.95f, .12f, z, 8.95f, .32f, z,
                        8.95f, .32f, z0, 8.95f, .12f, z0);
            }
        }

        // Ceiling light bars and structural beams.
        for (float z = 3f; z < 29f; z += 6f) {
            drawQuad3D(c, Color.rgb(205, 220, 222),
                    -2.4f, 5.26f, z - .14f, 2.4f, 5.26f, z - .14f,
                    2.4f, 5.26f, z + .14f, -2.4f, 5.26f, z + .14f);
            drawQuad3D(c, Color.rgb(74, 79, 84),
                    -9f, 5.18f, z - .24f, 9f, 5.18f, z - .24f,
                    9f, 5.18f, z + .24f, -9f, 5.18f, z + .24f);
        }

        // Simple 3D cover/crates make depth changes obvious while strafing.
        drawBox3D(c, -5.7f, 0f, 10f, 2.4f, 1.35f, 1.8f, Color.rgb(48, 67, 56));
        drawBox3D(c, 4.6f, 0f, 14f, 2.2f, 1.5f, 1.9f, Color.rgb(57, 65, 50));
        drawBox3D(c, -2.4f, 0f, 21f, 1.8f, 1.1f, 1.5f, Color.rgb(63, 55, 47));

        // Lane lines painted on the floor.
        for (float x : new float[]{-6f, -3f, 0f, 3f, 6f}) {
            drawQuad3D(c, Color.rgb(123, 126, 121),
                    x - .025f, .012f, 0f, x + .025f, .012f, 0f,
                    x + .025f, .012f, 31f, x - .025f, .012f, 31f);
        }

        // Subtle vignette only; there is no bitmap behind the geometry.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.2f));
        p.setColor(Color.argb(75, 60, 205, 220));
        c.drawRect(dp(3), dp(3), getWidth() - dp(3), getHeight() - dp(3), p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawWallBack(Canvas c, float z) {
        // Concrete back wall divided into bays, with a darker central door.
        for (float x = -9f; x < 9f; x += 3f) {
            int col = (((int)x) & 1) == 0 ? Color.rgb(47, 51, 54) : Color.rgb(41, 45, 48);
            drawQuad3D(c, col,
                    x, 0f, z, x + 3f, 0f, z,
                    x + 3f, 5.3f, z, x, 5.3f, z);
        }
        drawQuad3D(c, Color.rgb(29, 33, 36),
                -2.2f, 0f, z - .02f, 2.2f, 0f, z - .02f,
                2.2f, 3.9f, z - .02f, -2.2f, 3.9f, z - .02f);
        drawQuad3D(c, Color.rgb(143, 42, 42),
                -.35f, 4.35f, z - .03f, .35f, 4.35f, z - .03f,
                .35f, 4.55f, z - .03f, -.35f, 4.55f, z - .03f);
    }

    private void drawBox3D(Canvas c, float x, float y, float z, float w, float h, float d, int color) {
        // Draw far/top/side faces first, then front face.
        int dark = shade(color, .72f);
        int light = shade(color, 1.12f);
        drawQuad3D(c, dark,
                x, y, z + d, x + w, y, z + d,
                x + w, y + h, z + d, x, y + h, z + d);
        drawQuad3D(c, light,
                x, y + h, z, x + w, y + h, z,
                x + w, y + h, z + d, x, y + h, z + d);
        drawQuad3D(c, shade(color,.84f),
                x + w, y, z, x + w, y, z + d,
                x + w, y + h, z + d, x + w, y + h, z);
        drawQuad3D(c, color,
                x, y, z, x + w, y, z,
                x + w, y + h, z, x, y + h, z);
    }

    private int shade(int color, float factor) {
        int r = Math.min(255, Math.max(0, Math.round(Color.red(color) * factor)));
        int g = Math.min(255, Math.max(0, Math.round(Color.green(color) * factor)));
        int b = Math.min(255, Math.max(0, Math.round(Color.blue(color) * factor)));
        return Color.rgb(r,g,b);
    }

    private void drawQuad3D(Canvas c, int color,
                            float x1,float y1,float z1, float x2,float y2,float z2,
                            float x3,float y3,float z3, float x4,float y4,float z4) {
        float[] a = project3D(x1,y1,z1), b = project3D(x2,y2,z2);
        float[] d = project3D(x3,y3,z3), e = project3D(x4,y4,z4);
        if (a == null || b == null || d == null || e == null) return;
        Path path = new Path();
        path.moveTo(a[0],a[1]); path.lineTo(b[0],b[1]);
        path.lineTo(d[0],d[1]); path.lineTo(e[0],e[1]); path.close();
        p.setColor(color); c.drawPath(path,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(.45f));
        p.setColor(Color.argb(80, 180, 190, 194)); c.drawPath(path,p);
        p.setStyle(Paint.Style.FILL);
    }

    private float[] project3D(float wx, float wy, float wz) {
        float camX = playerLateral;
        float camZ = playerForward;
        // stanceOffset is positive when crouched; jumpOffset is negative while airborne.
        float camY = 1.70f - (stanceOffset / Math.max(1f,getHeight())) * 3.4f
                - (jumpOffset / Math.max(1f,getHeight())) * 3.0f;
        camY = clamp(camY, .72f, 2.65f);

        float dx = wx - camX, dy = wy - camY, dz = wz - camZ;
        double yaw = Math.toRadians(cameraYaw);
        float cy = (float)Math.cos(yaw), sy = (float)Math.sin(yaw);
        float cx = cy * dx - sy * dz;
        float cz = sy * dx + cy * dz;

        double pitch = Math.toRadians(cameraPitch);
        float cp = (float)Math.cos(pitch), sp = (float)Math.sin(pitch);
        float py = cp * dy - sp * cz;
        float pz = sp * dy + cp * cz;
        if (pz < .32f) return null;

        float fov = adsHeld ? 58f / Math.max(1f, scopeZoom(selectedScope) * .72f) : 82f;
        fov = clamp(fov, 24f, 90f);
        float focal = (float)(getWidth() * .5 / Math.tan(Math.toRadians(fov * .5)));
        float sx = getWidth()*.5f + (cx / pz) * focal;
        float syScreen = getHeight()*.5f - (py / pz) * focal;
        return new float[]{sx, syScreen, pz};
    }

    private void drawTraining(Canvas c, long now) {
        // World layer: lean rotates the scene, ADS zooms it, HUD stays screen-fixed.
        c.save();
        c.rotate(leanVisual, getWidth()/2f, getHeight()/2f);
        c.scale(adsZoom, adsZoom, crossX, crossY);
        drawTrainingBackdrop(c);
        for (TargetDot t : targets) drawTarget(c,t);
        drawWeapon(c);
        c.restore();
        drawCrosshair(c);
        drawHud(c,false);

        float elapsed = (now-sessionStartNs)/1_000_000_000f;
        int remain = Math.max(0, sessionSeconds - (int)elapsed);
        drawText(c, modeName()+"   " + scopeName(), getWidth()*.02f, getHeight()*.055f, dp(14), TEXT, true);
        drawCentered(c, String.format(Locale.US,"%02d",remain), getWidth()*.50f, getHeight()*.055f, dp(20), TEXT);
        String stats = "HITS " + hits + "   SHOTS " + shots + "   ACC " + accuracyText();
        drawText(c, stats, getWidth()*.67f, getHeight()*.055f, dp(13), TEXT, true);
        drawText(c, "PAUSE", getWidth()*.925f, getHeight()*.055f, dp(12), ACCENT, true);
        drawText(c, "FPS " + displayedFps, getWidth()*.018f, getHeight()*.975f, dp(10), Color.rgb(190,205,210), true);
        String ammoText = reloading ? "RELOADING" : String.format(Locale.US,"%02d / %02d",ammo,magazineSize);
        drawCentered(c, ammoText, getWidth()*.50f, getHeight()*.955f, dp(13), reloading?TARGET_RING:TEXT);

        if (mode==Mode.TRACKING) {
            String s = trackingFireMs <= 0 ? "TRACK 0%" : String.format(Locale.US,"TRACK %.0f%%",100*trackingOnTargetMs/trackingFireMs);
            drawText(c,s,getWidth()*.02f,getHeight()*.10f,dp(12),ACCENT,true);
        } else if (mode==Mode.REACTION && reactionHits>0) {
            drawText(c,String.format(Locale.US,"AVG REACTION %.0f ms",reactionTotalMs/reactionHits),getWidth()*.02f,getHeight()*.10f,dp(12),ACCENT,true);
        }
    }


    private void drawWeapon(Canvas c) {
        // First-person assault rifle + TWO visible tactical hands/forearms.
        // This is drawn as screen-space foreground geometry while the room itself is real 3D.
        float baseX = adsHeld ? getWidth()*.50f : getWidth()*.68f;
        float baseY = getHeight()*.93f;
        float scale = adsHeld ? .80f : 1.0f;
        float recoilY = recoilDrift * getHeight()*.012f;
        baseY -= recoilY;

        // Left support forearm (from lower-centre toward handguard).
        Path leftArm = new Path();
        leftArm.moveTo(getWidth()*.37f, getHeight()*1.02f);
        leftArm.lineTo(baseX-getWidth()*.17f*scale, baseY-getHeight()*.18f*scale);
        leftArm.lineTo(baseX-getWidth()*.11f*scale, baseY-getHeight()*.13f*scale);
        leftArm.lineTo(getWidth()*.48f, getHeight()*1.03f);
        leftArm.close();
        p.setColor(Color.rgb(36,42,47)); c.drawPath(leftArm,p);
        p.setColor(Color.rgb(20,24,27));
        c.drawCircle(baseX-getWidth()*.135f*scale, baseY-getHeight()*.155f*scale, getHeight()*.032f*scale,p);

        // Right trigger forearm and glove.
        Path rightArm = new Path();
        rightArm.moveTo(getWidth()*.78f, getHeight()*1.03f);
        rightArm.lineTo(baseX+getWidth()*.055f*scale, baseY-getHeight()*.09f*scale);
        rightArm.lineTo(baseX+getWidth()*.105f*scale, baseY-getHeight()*.035f*scale);
        rightArm.lineTo(getWidth()*.91f, getHeight()*1.03f);
        rightArm.close();
        p.setColor(Color.rgb(31,37,41)); c.drawPath(rightArm,p);
        p.setColor(Color.rgb(17,21,24));
        c.drawCircle(baseX+getWidth()*.065f*scale, baseY-getHeight()*.07f*scale, getHeight()*.034f*scale,p);

        // Rifle receiver.
        float rw=getWidth()*.25f*scale;
        RectF receiver=new RectF(baseX-rw*.44f,baseY-getHeight()*.20f*scale,
                baseX+rw*.34f,baseY-getHeight()*.095f*scale);
        p.setColor(Color.rgb(36,41,45)); c.drawRoundRect(receiver,dp(8),dp(8),p);
        // Red accent strip.
        p.setColor(Color.rgb(130,34,34));
        c.drawRect(receiver.left+rw*.08f,receiver.top+getHeight()*.025f*scale,
                receiver.right-rw*.08f,receiver.top+getHeight()*.043f*scale,p);

        // Handguard + barrel.
        p.setColor(Color.rgb(43,48,52));
        RectF handguard=new RectF(baseX-rw*.93f,baseY-getHeight()*.187f*scale,
                baseX-rw*.34f,baseY-getHeight()*.118f*scale);
        c.drawRoundRect(handguard,dp(5),dp(5),p);
        p.setColor(Color.rgb(22,26,29));
        c.drawRect(baseX-rw*1.16f,baseY-getHeight()*.168f*scale,
                baseX-rw*.91f,baseY-getHeight()*.141f*scale,p);
        // Rail slots.
        p.setColor(Color.rgb(86,92,96));
        for(int i=0;i<6;i++){
            float xx=handguard.left+rw*(.07f+i*.085f);
            c.drawRect(xx,handguard.top+dp(3),xx+dp(2.5f),handguard.top+getHeight()*.018f*scale,p);
        }

        // Pistol grip and magazine.
        p.setColor(Color.rgb(27,31,34));
        Path grip=new Path();
        grip.moveTo(baseX+rw*.05f,receiver.bottom-dp(2));
        grip.lineTo(baseX+rw*.20f,receiver.bottom+getHeight()*.12f*scale);
        grip.lineTo(baseX+rw*.33f,receiver.bottom+getHeight()*.10f*scale);
        grip.lineTo(baseX+rw*.22f,receiver.bottom-dp(1)); grip.close(); c.drawPath(grip,p);
        p.setColor(Color.rgb(46,51,55));
        Path mag=new Path();
        mag.moveTo(baseX-rw*.02f,receiver.bottom-dp(2));
        mag.lineTo(baseX+rw*.12f,receiver.bottom-dp(2));
        mag.lineTo(baseX+rw*.17f,receiver.bottom+getHeight()*.14f*scale);
        mag.lineTo(baseX+rw*.03f,receiver.bottom+getHeight()*.155f*scale); mag.close(); c.drawPath(mag,p);

        // Stock.
        p.setColor(Color.rgb(42,47,51));
        c.drawRect(baseX+rw*.30f,baseY-getHeight()*.18f*scale,
                baseX+rw*.62f,baseY-getHeight()*.12f*scale,p);

        // Holographic optic. During ADS it moves near screen centre.
        float opticCx=adsHeld?crossX:baseX-rw*.10f;
        float opticY=adsHeld?crossY+getHeight()*.025f:baseY-getHeight()*.275f*scale;
        float ow=getWidth()*(adsHeld?.067f:.052f)*scale;
        RectF optic=new RectF(opticCx-ow*.5f,opticY-getHeight()*.055f*scale,
                opticCx+ow*.5f,opticY+getHeight()*.025f*scale);
        p.setColor(Color.rgb(55,62,67)); c.drawRoundRect(optic,dp(5),dp(5),p);
        RectF glass=new RectF(optic.left+dp(5),optic.top+dp(5),optic.right-dp(5),optic.bottom-dp(5));
        p.setColor(Color.argb(235,15,28,31)); c.drawRoundRect(glass,dp(3),dp(3),p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.1f)); p.setColor(Color.rgb(205,55,55));
        c.drawCircle(glass.centerX(),glass.centerY(),dp(2.6f),p); p.setStyle(Paint.Style.FILL);

        // Glove finger blocks wrapping the weapon make the hands read as gripping it.
        p.setColor(Color.rgb(16,20,23));
        for(int i=0;i<3;i++){
            RectF finger=new RectF(baseX-rw*(.44f-i*.08f),baseY-getHeight()*(.175f-i*.004f)*scale,
                    baseX-rw*(.37f-i*.08f),baseY-getHeight()*.125f*scale);
            c.drawRoundRect(finger,dp(4),dp(4),p);
        }
    }

    private void drawHud(Canvas c, boolean edit) {
        for (HudButton b : hud) drawHudButton(c,b,edit);
        drawJoystick(c,edit);
        if (edit) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(110,64,219,169));
            RectF safe = new RectF(getWidth()*.42f,getHeight()*.16f,getWidth()*.76f,getHeight()*.78f);
            c.drawRoundRect(safe,24,24,p); p.setStyle(Paint.Style.FILL);
            drawCentered(c,"KEEP THIS AIMING ZONE CLEAR",safe.centerX(),safe.centerY(),dp(13),Color.argb(180,235,242,246));
        }
    }

    private void drawHudButton(Canvas c, HudButton b, boolean edit) {
        boolean active = b.activePointer >= 0 || (b.type==HudType.FIRE && firing) || (b.type==HudType.ADS && adsHeld) || b==draggedButton;
        int alpha=(int)(255f*(edit?Math.min(0.85f,hudOpacity+0.12f):hudOpacity));
        int base=Color.argb(alpha,56,69,79);
        p.setColor(active ? activeColor(b.type) : base);
        c.drawCircle(b.x,b.y,b.r,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(Color.argb(190,205,220,228)); c.drawCircle(b.x,b.y,b.r,p); p.setStyle(Paint.Style.FILL);
        drawCentered(c,b.label,b.x,b.y+dp(4),Math.max(dp(8),b.r*.28f),TEXT);
    }

    private int activeColor(HudType type) {
        return switch(type) {
            case FIRE -> Color.argb(225,220,55,55);       // red
            case ADS -> Color.argb(225,66,133,244);       // blue
            case LEAN_L, LEAN_R -> Color.argb(225,180,95,230); // purple
            case JUMP -> Color.argb(225,245,170,55);      // orange
            case CROUCH, PRONE -> Color.argb(225,70,190,120); // green
            case RELOAD -> Color.argb(225,55,190,210);    // cyan
            case MELEE -> Color.argb(225,230,120,55);     // amber
            case JOYSTICK -> Color.argb(225,120,140,155);
        };
    }

    private void drawJoystick(Canvas c, boolean edit) {
        p.setColor(Color.argb((int)(255f*(edit?Math.min(0.80f,hudOpacity):hudOpacity*0.72f)),70,84,94)); c.drawCircle(joyCenterX,joyCenterY,joystick.r,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(130,205,220,228)); c.drawCircle(joyCenterX,joyCenterY,joystick.r,p); p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(155,150,166,176)); c.drawCircle(joyKnobX,joyKnobY,joystick.r*.42f,p);
        drawCentered(c,"MOVE",joyCenterX,joyCenterY-joystick.r*1.18f,dp(10),MUTED);
    }


    private void drawHudEditControls(Canvas c) {
        RectF minus=new RectF(getWidth()*.035f,getHeight()*.865f,getWidth()*.095f,getHeight()*.945f);
        RectF plus=new RectF(getWidth()*.105f,getHeight()*.865f,getWidth()*.165f,getHeight()*.945f);
        RectF resetHud=new RectF(getWidth()*.185f,getHeight()*.865f,getWidth()*.315f,getHeight()*.945f);
        drawAction(c,minus,"SIZE −",false);
        drawAction(c,plus,"SIZE +",false);
        drawAction(c,resetHud,"RESET HUD",false);
        drawText(c, selectedHudButton==null?"Tap a HUD button, then resize it":"Selected: "+selectedHudButton.label,
                getWidth()*.34f,getHeight()*.915f,dp(11),MUTED,false);
        drawText(c,String.format(Locale.US,"Opacity %.0f%%",hudOpacity*100),getWidth()*.58f,getHeight()*.915f,dp(11),MUTED,false);
    }

    private void drawSensitivity(Canvas c) {
        p.setColor(BG); c.drawRect(0,0,getWidth(),getHeight(),p);
        drawTopTitle(c,"SENSITIVITY — DELTA-STYLE SMOOTH CURVE");
        drawText(c,"Camera",getWidth()*.20f,getHeight()*.16f,dp(14),ACCENT,true);
        drawText(c,"Firing",getWidth()*.35f,getHeight()*.16f,dp(14),ACCENT,true);
        drawText(c,"− / +",getWidth()*.52f,getHeight()*.16f,dp(14),MUTED,true);

        float startY=getHeight()*.205f;
        float rowH=getHeight()*.047f;
        for (int i=0;i<13;i++) {
            float y=startY+i*rowH;
            if (y>getHeight()*.84f) break;
            drawText(c,scopeName(i),getWidth()*.07f,y,dp(12),TEXT,true);
            drawText(c,String.format(Locale.US,"%.0f",cameraSens[i]),getWidth()*.21f,y,dp(12),TEXT,false);
            drawText(c,String.format(Locale.US,"%.0f",firingSens[i]),getWidth()*.36f,y,dp(12),TEXT,false);
            drawSmallButton(c,getWidth()*.50f,y-dp(16),"−C");
            drawSmallButton(c,getWidth()*.56f,y-dp(16),"+C");
            drawSmallButton(c,getWidth()*.64f,y-dp(16),"−F");
            drawSmallButton(c,getWidth()*.70f,y-dp(16),"+F");
        }

        float x=getWidth()*.77f;
        float y=getHeight()*.23f;
        drawText(c,"GLOBAL",x,y,dp(15),ACCENT,true); y+=getHeight()*.07f;
        drawGlobalRow(c,"H Swipe",horizontalSwipe,x,y,0); y+=getHeight()*.085f;
        drawGlobalRow(c,"V Swipe",verticalSwipe,x,y,1); y+=getHeight()*.085f;
        drawGlobalRow(c,"H Fire",horizontalFire,x,y,2); y+=getHeight()*.085f;
        drawGlobalRow(c,"V Fire",verticalFire,x,y,3); y+=getHeight()*.085f;
        drawGlobalRow(c,"Target %",targetScale*100f,x,y,4);
        drawText(c,"Defaults: Fixed turning, Hold ADS, Instant transition.",x,getHeight()*.75f,dp(11),MUTED,false);
        drawText(c,"Target size can be reduced for harder precision drills.",x,getHeight()*.80f,dp(10),MUTED,false);

        backRect.set(getWidth()*.02f,getHeight()*.02f,getWidth()*.10f,getHeight()*.09f);
        resetRect.set(getWidth()*.75f,getHeight()*.83f,getWidth()*.86f,getHeight()*.91f);
        saveRect.set(getWidth()*.87f,getHeight()*.83f,getWidth()*.98f,getHeight()*.91f);
        drawAction(c,backRect,"BACK",false);
        drawAction(c,resetRect,"RESET",false);
        drawAction(c,saveRect,"SAVE",true);
    }

    private void drawGlobalRow(Canvas c,String name,float value,float x,float y,int idx) {
        drawText(c,name,x,y,dp(11),TEXT,true);
        drawText(c,String.format(Locale.US,"%.0f",value),x+getWidth()*.10f,y,dp(12),TEXT,false);
        drawSmallButton(c,x+getWidth()*.145f,y-dp(16),"−");
        drawSmallButton(c,x+getWidth()*.185f,y-dp(16),"+");
    }

    private void drawSmallButton(Canvas c,float x,float y,String text) {
        RectF r=new RectF(x,y,x+getWidth()*.045f,y+getHeight()*.042f);
        p.setColor(PANEL2); c.drawRoundRect(r,9,9,p); drawCentered(c,text,r.centerX(),r.centerY()+dp(4),dp(10),TEXT);
    }

    private void drawTopTitle(Canvas c,String title) {
        drawText(c,title,getWidth()*.04f,getHeight()*.08f,dp(18),TEXT,true);
        p.setColor(ACCENT); c.drawRect(getWidth()*.04f,getHeight()*.105f,getWidth()*.96f,getHeight()*.109f,p);
    }

    private void drawBottomAction(Canvas c,String label) {
        backRect.set(getWidth()*.02f,getHeight()*.02f,getWidth()*.10f,getHeight()*.09f);
        saveRect.set(getWidth()*.79f,getHeight()*.87f,getWidth()*.96f,getHeight()*.95f);
        drawAction(c,backRect,"BACK",false);
        drawAction(c,saveRect,"SAVE",true);
    }

    private void drawAction(Canvas c,RectF r,String label,boolean accent) {
        p.setColor(accent ? ACCENT : PANEL2); c.drawRoundRect(r,16,16,p);
        drawCentered(c,label,r.centerX(),r.centerY()+dp(5),dp(13),accent?Color.rgb(5,28,22):TEXT);
    }

    private void drawTarget(Canvas c, TargetDot t) {
        p.setColor(TARGET); c.drawCircle(t.x,t.y,t.r,p);
        p.setColor(Color.rgb(255,238,238)); c.drawCircle(t.x,t.y,t.r*.34f,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(TARGET_RING); c.drawCircle(t.x,t.y,t.r*1.16f,p); p.setStyle(Paint.Style.FILL);
    }

    private void drawCrosshair(Canvas c) {
        p.setColor(Color.WHITE); p.setStrokeWidth(dp(2));
        float g=dp(7), len=dp(13);
        c.drawLine(crossX-g-len,crossY,crossX-g,crossY,p);
        c.drawLine(crossX+g,crossY,crossX+g+len,crossY,p);
        c.drawLine(crossX,crossY-g-len,crossX,crossY-g,p);
        c.drawLine(crossX,crossY+g,crossX,crossY+g+len,p);
        c.drawCircle(crossX,crossY,dp(1.5f),p);
    }

    private void updateTraining(long now, float dt) {
        if ((now-sessionStartNs)/1_000_000_000f >= sessionSeconds) {
            showSummary();
            return;
        }

        // Smooth camera effects from action buttons.
        float leanTarget=leanDirection*5.5f;
        leanVisual += (leanTarget-leanVisual)*Math.min(1f,dt*14f);
        float zoomTarget=adsHeld?scopeZoom(selectedScope):1f;
        // Handling 40 baseline: deliberately not instant; approximates the ~457 ms ADS feel.
        adsZoom += (zoomTarget-adsZoom)*Math.min(1f,dt*7f);
        if (airborne) {
            jumpOffset += jumpVelocity*dt;
            jumpVelocity += getHeight()*2.55f*dt;
            if (jumpOffset >= 0f) { jumpOffset=0f; jumpVelocity=0f; airborne=false; }
        }
        if (reloading && now >= reloadFinishNs) { ammo=magazineSize; reloading=false; }

        if (mode==Mode.TRACKING || mode==Mode.SWITCHING) {
            for (TargetDot t:targets) {
                t.x += t.vx*dt; t.y += t.vy*dt;
                float margin=t.r*1.3f;
                if (t.x<margin || t.x>getWidth()-margin) { t.vx=-t.vx; t.x=clamp(t.x,margin,getWidth()-margin); }
                if (t.y<getHeight()*.15f+margin || t.y>getHeight()*.92f-margin) { t.vy=-t.vy; t.y=clamp(t.y,getHeight()*.15f+margin,getHeight()*.92f-margin); }
            }
        }

        if (joystickPointer>=0) {
            playerLateral += strafe*dt*1.7f;
            playerForward += forward*dt*1.4f;
            playerLateral=clamp(playerLateral,-4f,4f);
            playerForward=clamp(playerForward,-3f,3f);
            // Parallax makes movement immediately visible.
            if(mode!=Mode.STATIC_AIM) shiftTargets(-strafe*dt*getWidth()*.34f, forward*dt*getHeight()*.08f);
        }

        if (mode==Mode.REACTION && !reactionVisible && now>=reactionDelayUntilNs) {
            spawnSingleTarget(); reactionVisible=true; reactionShownNs=now;
        }

        if (firing) {
            if (mode==Mode.TRACKING) {
                trackingFireMs += dt*1000.0;
                if (isAnyTargetOnCrosshair()) trackingOnTargetMs += dt*1000.0;
            } else {
                if (now-lastAutoShotNs>=SHOT_INTERVAL_NS) { doShot(now); lastAutoShotNs=now; }
            }
            if (mode==Mode.RECOIL) {
                recoilDrift += dt*getHeight()*.22f;
                shiftTargets(0,dt*getHeight()*.22f);
            }
        }
    }

    private void startTraining() {
        screen=Screen.TRAINING;
        shots=hits=0; reactionTotalMs=0; reactionHits=0; trackingFireMs=trackingOnTargetMs=0;
        firing=false; adsHeld=false; leanDirection=0; recoilDrift=0; cameraYaw=0; cameraPitch=0;
        ammo=magazineSize; reloading=false; reloadFinishNs=0; airborne=false; jumpOffset=0; jumpVelocity=0;
        crossX=getWidth()/2f; crossY=getHeight()/2f; playerLateral=playerForward=0; forward=0; strafe=0;
        firePointer=adsPointer=leanLeftPointer=leanRightPointer=aimPointer=joystickPointer=-1;
        sessionStartNs=System.nanoTime(); lastFrameNs=sessionStartNs; lastAutoShotNs=0;
        targets.clear();
        if (mode==Mode.SWITCHING) {
            for(int i=0;i<3;i++) targets.add(randomTarget(true));
        } else if (mode==Mode.REACTION) {
            reactionVisible=false; scheduleReaction(sessionStartNs);
        } else {
            spawnSingleTarget();
            if(mode==Mode.STATIC_AIM && !targets.isEmpty()){ targets.get(0).x=getWidth()*.60f; targets.get(0).y=getHeight()*.42f; }
        }
    }

    private void showSummary() {
        String s;
        if (mode==Mode.TRACKING) {
            double pct=trackingFireMs<=0?0:100*trackingOnTargetMs/trackingFireMs;
            s=String.format(Locale.US,"Tracking %.0f%%",pct);
        } else if (mode==Mode.REACTION && reactionHits>0) {
            s=String.format(Locale.US,"Avg reaction %.0f ms",reactionTotalMs/reactionHits);
        } else {
            s="Accuracy "+accuracyText()+" • Hits "+hits;
        }
        screen=Screen.HOME;
        toast("Session complete — "+s,3800);
    }

    private void spawnSingleTarget() {
        targets.clear(); targets.add(randomTarget(mode==Mode.TRACKING));
    }

    private TargetDot randomTarget(boolean moving) {
        float r=getHeight()*(mode==Mode.TRACKING?.046f:.041f)*targetScale;
        float x=getWidth()*(.27f+rng.nextFloat()*.47f);
        float y=getHeight()*(.22f+rng.nextFloat()*.57f);
        float speed=getWidth()*(.07f+rng.nextFloat()*.055f);
        float ang=(float)(rng.nextDouble()*Math.PI*2);
        return new TargetDot(x,y,r,moving?(float)Math.cos(ang)*speed:0,moving?(float)Math.sin(ang)*speed:0);
    }

    private void scheduleReaction(long now) {
        reactionDelayUntilNs=now+(700+rng.nextInt(1300))*1_000_000L;
    }

    private void doShot(long now) {
        if (reloading) return;
        if (ammo <= 0) { startReload(now); return; }
        ammo--;
        if (mode==Mode.REACTION && !reactionVisible) { shots++; return; }
        shots++;

        // M4A1-style training baseline from the supplied weapon panel:
        // 800 rpm, 45 rounds, vertical recoil multiplier ~0.19x, horizontal ~0.48x.
        float vKick=getHeight()*.0052f;
        float hKick=(rng.nextFloat()-.5f)*getWidth()*.0019f;
        crossY=clamp(crossY-vKick,getHeight()*.24f,getHeight()*.76f);
        crossX=clamp(crossX+hKick,getWidth()*.25f,getWidth()*.75f);
        cameraPitch-=0.22f;
        cameraYaw+=hKick/getWidth()*12f;

        // Accuracy/spread baseline: tighter in ADS, looser from hip.
        float spreadPx=getHeight()*(adsHeld?.0025f:.0105f);
        float shotX=crossX+(rng.nextFloat()-.5f)*spreadPx;
        float shotY=crossY+(rng.nextFloat()-.5f)*spreadPx;
        int hitIndex=findTargetAt(shotX,shotY);
        if (hitIndex>=0) {
            hits++;
            if (mode==Mode.REACTION) {
                reactionTotalMs+=(now-reactionShownNs)/1_000_000.0; reactionHits++;
                targets.clear(); reactionVisible=false; scheduleReaction(now);
            } else if (mode==Mode.SWITCHING) {
                targets.set(hitIndex,randomTarget(true));
            } else if (mode==Mode.RECOIL) {
                // Keep one target so continuous recoil correction is trained.
            } else if (mode!=Mode.STATIC_AIM) {
                spawnSingleTarget();
            }
        }
        if (ammo<=0) startReload(now);
    }

    private void startReload(long now) {
        if (reloading || ammo==magazineSize) return;
        reloading=true; firing=false; firePointer=-1;
        reloadFinishNs=now+RELOAD_NS;
    }

    private int findTargetAt(float x,float y) {
        for(int i=0;i<targets.size();i++) {
            TargetDot t=targets.get(i); float dx=t.x-x,dy=t.y-y;
            if(dx*dx+dy*dy<=t.r*t.r) return i;
        }
        return -1;
    }

    private int findTargetOnCrosshair() {
        for(int i=0;i<targets.size();i++) {
            TargetDot t=targets.get(i); float dx=t.x-crossX,dy=t.y-crossY;
            if(dx*dx+dy*dy<=t.r*t.r) return i;
        }
        return -1;
    }
    private boolean isAnyTargetOnCrosshair(){ return findTargetOnCrosshair()>=0; }

    private void shiftTargets(float dx,float dy) {
        for(TargetDot t:targets){ t.x+=dx; t.y+=dy; }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action=e.getActionMasked();
        int index=e.getActionIndex();
        int pid=e.getPointerId(index);
        float x=e.getX(index), y=e.getY(index);

        if (screen==Screen.HOME) return handleHomeTouch(e,action,index,x,y);
        if (screen==Screen.SENSITIVITY) return handleSensitivityTouch(e,action,index,x,y);
        if (screen==Screen.HUD_EDIT) return handleHudEditTouch(e,action,index,pid,x,y);

        if (screen==Screen.TRAINING) {
            if (action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
                if (x>getWidth()*.90f && y<getHeight()*.10f) { screen=Screen.HOME; firing=false; adsHeld=false; leanDirection=0; return true; }
                HudButton b=findHudAt(x,y);
                if (b!=null) {
                    b.activePointer=pid;
                    switch(b.type) {
                        case FIRE -> { if(firePointer<0 && !reloading){firePointer=pid;firing=true;lastAutoShotNs=0;doShot(System.nanoTime());lastAutoShotNs=System.nanoTime();} }
                        case ADS -> { if(adsPointer<0){adsPointer=pid;adsHeld=true;} }
                        case LEAN_L -> { if(leanLeftPointer<0){leanLeftPointer=pid;leanDirection=-1;} }
                        case LEAN_R -> { if(leanRightPointer<0){leanRightPointer=pid;leanDirection=1;} }
                        case JUMP -> { if(!airborne){ airborne=true; jumpVelocity=-getHeight()*.72f; } }
                        case CROUCH -> { stanceOffset=getHeight()*.035f; }
                        case PRONE -> { stanceOffset=getHeight()*.075f; }
                        case RELOAD -> { startReload(System.nanoTime()); }
                        case MELEE -> { /* reserved for later weapon work */ }
                        default -> { }
                    }
                } else if (insideJoystick(x,y) && joystickPointer<0) {
                    joystickPointer=pid; joystick.activePointer=pid; updateJoystick(x,y);
                } else if (aimPointer<0) {
                    aimPointer=pid; aimLastX=x; aimLastY=y;
                }
            } else if (action==MotionEvent.ACTION_MOVE) {
                for(int i=0;i<e.getPointerCount();i++) {
                    int id=e.getPointerId(i); float px=e.getX(i),py=e.getY(i);
                    if(id==aimPointer) handleAimMove(px,py);
                    if(id==joystickPointer) updateJoystick(px,py);
                }
            } else if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
                for(HudButton b:allHud()) if(b.activePointer==pid || action==MotionEvent.ACTION_CANCEL) b.activePointer=-1;
                if(pid==firePointer){firePointer=-1;firing=false;}
                if(pid==adsPointer){adsPointer=-1;adsHeld=false;}
                if(pid==leanLeftPointer){leanLeftPointer=-1;if(leanRightPointer<0)leanDirection=0;}
                if(pid==leanRightPointer){leanRightPointer=-1;if(leanLeftPointer<0)leanDirection=0;}
                if(pid==aimPointer){aimPointer=-1;}
                if(pid==joystickPointer){joystickPointer=-1;strafe=0;forward=0;joyKnobX=joyCenterX;joyKnobY=joyCenterY;}
                // Crouch/prone are momentary in trainer prototype.
                if(action!=MotionEvent.ACTION_POINTER_UP) stanceOffset=0f;
                if(action==MotionEvent.ACTION_CANCEL){firePointer=adsPointer=leanLeftPointer=leanRightPointer=aimPointer=joystickPointer=-1;firing=false;adsHeld=false;leanDirection=0;strafe=forward=0;}
            }
            return true;
        }
        return true;
    }

    private boolean handleHomeTouch(MotionEvent e,int action,int index,float x,float y) {
        if(action!=MotionEvent.ACTION_UP) return true;
        float left=getWidth()*.045f, top=getHeight()*.28f, cardW=getWidth()*.135f, cardH=getHeight()*.25f, gap=getWidth()*.012f;
        for(int i=0;i<6;i++) {
            RectF r=new RectF(left+i*(cardW+gap),top,left+i*(cardW+gap)+cardW,top+cardH);
            if(r.contains(x,y)){ mode=Mode.values()[i]; return true; }
        }
        if(startRect.contains(x,y)){startTraining();return true;}
        if(hudRect.contains(x,y)){snapshotForEdit();screen=Screen.HUD_EDIT;return true;}
        if(sensRect.contains(x,y)){snapshotForEdit();screen=Screen.SENSITIVITY;return true;}
        if(durationRect.contains(x,y)){sessionSeconds=sessionSeconds==30?60:sessionSeconds==60?120:30;return true;}
        if(scopeRect.contains(x,y)){selectedScope++;if(selectedScope>12)selectedScope=0;return true;}
        return true;
    }

    private boolean handleHudEditTouch(MotionEvent e,int action,int index,int pid,float x,float y) {
        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
            if(backRect.contains(x,y)){restoreEditSnapshot();screen=Screen.HOME;return true;}
            if(saveRect.contains(x,y)){savePrefs();screen=Screen.HOME;toast("HUD saved",900);return true;}
            if(y>getHeight()*.855f && x<getWidth()*.325f) {
                if(x<getWidth()*.10f && selectedHudButton!=null) { selectedHudButton.nr=clamp(selectedHudButton.nr-.006f,.025f,.13f); updateHudPixels(); }
                else if(x<getWidth()*.17f && selectedHudButton!=null) { selectedHudButton.nr=clamp(selectedHudButton.nr+.006f,.025f,.13f); updateHudPixels(); }
                else if(x<getWidth()*.325f) { resetHudLayout(); toast("HUD reset",900); }
                return true;
            }
            HudButton b=findHudAtIncludingJoystick(x,y);
            if(b!=null && hudEditPointer<0){hudEditPointer=pid;draggedButton=b;selectedHudButton=b;}
        } else if(action==MotionEvent.ACTION_MOVE && draggedButton!=null) {
            for(int i=0;i<e.getPointerCount();i++) if(e.getPointerId(i)==hudEditPointer){
                draggedButton.x=clamp(e.getX(i),draggedButton.r,getWidth()-draggedButton.r);
                draggedButton.y=clamp(e.getY(i),draggedButton.r,getHeight()-draggedButton.r);
                draggedButton.nx=draggedButton.x/getWidth(); draggedButton.ny=draggedButton.y/getHeight();
                if(draggedButton==joystick){joyCenterX=draggedButton.x;joyCenterY=draggedButton.y;joyKnobX=joyCenterX;joyKnobY=joyCenterY;}
            }
        } else if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
            if(pid==hudEditPointer || action==MotionEvent.ACTION_CANCEL){hudEditPointer=-1;draggedButton=null;}
        }
        return true;
    }

    private boolean handleSensitivityTouch(MotionEvent e,int action,int index,float x,float y) {
        if(action!=MotionEvent.ACTION_UP) return true;
        if(backRect.contains(x,y)){restoreEditSnapshot();screen=Screen.HOME;return true;}
        if(saveRect.contains(x,y)){savePrefs();screen=Screen.HOME;toast("Sensitivity saved",900);return true;}
        if(resetRect.contains(x,y)){resetSensitivity();toast("Sensitivity reset",900);return true;}

        float startY=getHeight()*.205f,rowH=getHeight()*.047f;
        int row=Math.round((y-startY)/rowH);
        if(row>=0 && row<13 && Math.abs(y-(startY+row*rowH))<rowH*.48f) {
            if(x>getWidth()*.49f && x<getWidth()*.55f) cameraSens[row]=clamp(cameraSens[row]-5,20,300);
            else if(x>getWidth()*.55f && x<getWidth()*.62f) cameraSens[row]=clamp(cameraSens[row]+5,20,300);
            else if(x>getWidth()*.63f && x<getWidth()*.69f) firingSens[row]=clamp(firingSens[row]-5,20,300);
            else if(x>getWidth()*.69f && x<getWidth()*.76f) firingSens[row]=clamp(firingSens[row]+5,20,300);
            return true;
        }
        // Global minus/plus zones.
        float baseY=getHeight()*.30f, step=getHeight()*.085f;
        for(int i=0;i<5;i++){
            float yy=baseY+i*step;
            if(Math.abs(y-yy)<step*.42f){
                if(x>getWidth()*.905f && x<getWidth()*.95f) adjustGlobal(i,-5);
                else if(x>getWidth()*.95f) adjustGlobal(i,5);
            }
        }
        return true;
    }

    private void adjustGlobal(int i,float d){
        if(i==0)horizontalSwipe=clamp(horizontalSwipe+d,50,300);
        if(i==1)verticalSwipe=clamp(verticalSwipe+d,50,300);
        if(i==2)horizontalFire=clamp(horizontalFire+d,50,300);
        if(i==3)verticalFire=clamp(verticalFire+d,50,300);
        if(i==4)targetScale=clamp(targetScale+d/100f,.30f,1.30f);
    }


    private void snapshotForEdit(){
        System.arraycopy(cameraSens,0,snapCamera,0,13);
        System.arraycopy(firingSens,0,snapFiring,0,13);
        snapHSwipe=horizontalSwipe; snapVSwipe=verticalSwipe; snapHFire=horizontalFire; snapVFire=verticalFire; snapHudOpacity=hudOpacity; snapTargetScale=targetScale;
        snapHud.clear();
        for(HudButton b:allHud()) snapHud.add(new float[]{b.nx,b.ny,b.nr});
    }

    private void restoreEditSnapshot(){
        System.arraycopy(snapCamera,0,cameraSens,0,13);
        System.arraycopy(snapFiring,0,firingSens,0,13);
        horizontalSwipe=snapHSwipe; verticalSwipe=snapVSwipe; horizontalFire=snapHFire; verticalFire=snapVFire; hudOpacity=snapHudOpacity; targetScale=snapTargetScale;
        List<HudButton> all=allHud();
        for(int i=0;i<all.size() && i<snapHud.size();i++){float[] a=snapHud.get(i); all.get(i).nx=a[0];all.get(i).ny=a[1];all.get(i).nr=a[2];}
        updateHudPixels();
    }

    private void resetHudLayout(){
        hud.clear();
        initHud();
        selectedHudButton=null; draggedButton=null; hudEditPointer=-1;
        updateHudPixels();
    }

    private void resetSensitivity(){
        float[] c={190,150,140,125,110,100,90,85,80,75,70,65,60};
        float[] f={180,160,145,130,115,105,95,90,85,80,75,70,65};
        System.arraycopy(c,0,cameraSens,0,c.length); System.arraycopy(f,0,firingSens,0,f.length);
        horizontalSwipe=240;verticalSwipe=210;horizontalFire=100;verticalFire=120;targetScale=1.0f;
    }

    private void handleAimMove(float x,float y) {
        float dx=x-aimLastX,dy=y-aimLastY; aimLastX=x;aimLastY=y;
        int idx=Math.max(0,Math.min(selectedScope,12));
        float sens=(firing?firingSens[idx]:cameraSens[idx]);
        float hx=firing?horizontalFire/100f:horizontalSwipe/240f;
        float vy=firing?verticalFire/120f:verticalSwipe/210f;
        float factor=1.25f*(sens/150f)*(adsHeld?.84f:1f);

        // The reticle now visibly follows the swipe inside a central aiming window.
        // The room also rotates with it, so it feels like turning a first-person camera,
        // not like targets simply chasing a fixed dot.
        crossX += dx*factor*hx*.72f;
        crossY += dy*factor*vy*.72f;
        float minX=getWidth()*.34f,maxX=getWidth()*.66f,minY=getHeight()*.28f,maxY=getHeight()*.72f;
        float overflowX=0, overflowY=0;
        if(crossX<minX){overflowX=crossX-minX;crossX=minX;}
        if(crossX>maxX){overflowX=crossX-maxX;crossX=maxX;}
        if(crossY<minY){overflowY=crossY-minY;crossY=minY;}
        if(crossY>maxY){overflowY=crossY-maxY;crossY=maxY;}

        cameraYaw += dx*factor*hx*.055f + overflowX*.018f;
        cameraPitch += dy*factor*vy*.045f + overflowY*.018f;
        cameraPitch=clamp(cameraPitch,-35f,35f);
        // Camera rotation creates parallax. STATIC AIM intentionally leaves the round target
        // screen-stationary while the crosshair and room move, matching the requested drill.
        if (mode!=Mode.STATIC_AIM) shiftTargets(-dx*factor*hx*.30f,-dy*factor*vy*.30f);
    }

    private void updateJoystick(float x,float y) {
        float dx=x-joyCenterX,dy=y-joyCenterY;
        float max=joystick.r*.72f;
        float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>max){dx*=max/len;dy*=max/len;}
        joyKnobX=joyCenterX+dx;joyKnobY=joyCenterY+dy;
        strafe=clamp(dx/max,-1,1);
        forward=clamp(-dy/max,-1,1);
    }

    private boolean insideJoystick(float x,float y){float dx=x-joyCenterX,dy=y-joyCenterY;return dx*dx+dy*dy<=joystick.r*joystick.r;}
    private HudButton findHudAt(float x,float y){for(HudButton b:hud)if(b.hit(x,y))return b;return null;}
    private HudButton findHudAtIncludingJoystick(float x,float y){HudButton b=findHudAt(x,y);if(b!=null)return b;return joystick.hit(x,y)?joystick:null;}

    private float scopeZoom(int i){
        if(i<=0) return 1.08f;
        float[] z={1.08f,1.25f,1.42f,1.58f,1.74f,1.88f,2.02f,2.14f,2.25f,2.36f,2.46f,2.55f,2.65f};
        return z[Math.max(0,Math.min(i,12))];
    }

    private String modeName(){return switch(mode){case FLICK->"FLICK";case TRACKING->"TRACKING";case SWITCHING->"TARGET SWITCH";case REACTION->"REACTION";case RECOIL->"RECOIL";case STATIC_AIM->"STATIC AIM";};}
    private String scopeName(){return scopeName(selectedScope);}
    private String scopeName(int i){return i==0?"HIP":i==1?"1x / RED DOT":i+"x";}
    private String accuracyText(){return shots==0?"0%":String.format(Locale.US,"%.0f%%",100.0*hits/shots);}

    private void toast(String s,long ms){toastText=s;toastUntilNs=System.nanoTime()+ms*1_000_000L;}
    private void drawText(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?android.graphics.Typeface.DEFAULT_BOLD:android.graphics.Typeface.DEFAULT);p.setTextAlign(Paint.Align.LEFT);c.drawText(s,x,y,p);}
    private void drawCentered(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private enum HudType { FIRE, ADS, LEAN_L, LEAN_R, JUMP, CROUCH, PRONE, RELOAD, MELEE, JOYSTICK }
    private static class HudButton {
        String label; float nx,ny,nr,x,y,r; HudType type; int activePointer=-1;
        HudButton(String label,float nx,float ny,float nr,HudType type){this.label=label;this.nx=nx;this.ny=ny;this.nr=nr;this.type=type;}
        boolean hit(float px,float py){float dx=px-x,dy=py-y;return dx*dx+dy*dy<=r*r;}
    }
    private static class TargetDot {
        float x,y,r,vx,vy;
        TargetDot(float x,float y,float r,float vx,float vy){this.x=x;this.y=y;this.r=r;this.vx=vx;this.vy=vy;}
    }
}
