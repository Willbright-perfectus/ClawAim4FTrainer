# ClawAim 4F Trainer v1.2.0

Four-finger Android aim trainer prototype tuned around a Delta Force-style HUD and sensitivity curve.

## v1.2.0 changes
- Reticle now visibly follows swipe input inside a central aim window while the pseudo-3D room also rotates/parallaxes.
- Hold ADS visibly zooms the world and brings the rifle sight toward the reticle.
- Hold Lean Left/Right visibly tilts the first-person camera.
- Movement joystick now supports strafe + forward/backward parallax.
- Jump, crouch and prone now have visible camera-height effects.
- HUD buttons use distinct pressed colors instead of one universal active color.
- Removed pressed-button toast messages during training.
- HUD editor and sensitivity screen now have BACK (discard) and SAVE (commit) separately.
- Camera/firing sensitivity remains adjustable per hip/1x through 12x+, plus horizontal/vertical swipe/fire multipliers.
- Basic assault-rifle silhouette and light recoil kick added as a foundation for later magazine/weapon work.
