# ClawAim 4F Trainer

A landscape Android aim trainer designed around a four-finger claw layout with Hold ADS and a clear right-thumb aiming zone.

## Included training modes
- Flick: fast target acquisition
- Tracking: keep the crosshair on a moving target while holding fire
- Target Switch: move between multiple moving targets
- Reaction: measure first-shot reaction time
- Recoil: continuous-fire pull-down practice

## Four-finger controls
- Left thumb: movement/strafe joystick
- Left index: FIRE
- Right thumb: swipe anywhere in the clear aiming zone
- Right index: ADS and optional lean/action buttons

The HUD editor lets you drag the buttons so the trainer can match your real game layout instead of forcing an Aim Lab/Aim Champ layout.

## Default sensitivity preset
Camera: Hip 190; 1x 150; 2x 140; 3x 125; 4x 110; 5x 100; 6x 90; 7x 85; 8x 80; 9x 75; 10x 70; 11x 65; 12x+ 60.

Firing: Hip 180; 1x 160; 2x 145; 3x 130; 4x 115; 5x 105; 6x 95; 7x 90; 8x 85; 9x 80; 10x 75; 11x 70; 12x+ 65.

Global: H Swipe 240; V Swipe 210; H Fire 100; V Fire 120.

Important: Delta Force's internal touch-to-camera conversion is not public. The app therefore reproduces the same *relative sensitivity curve and four-finger workflow*, but a raw value such as 150 cannot be guaranteed to be mathematically 1:1 between two different game engines. Use the in-app controls to fine-tune by small increments if necessary.

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync. JDK 17 is recommended.
3. Build > Build APK(s).
4. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Build automatically with GitHub Actions
Push the project to GitHub. The included workflow builds an installable debug APK and uploads it as an Actions artifact.

## Android requirements
- Android 8.0 (API 26) or newer
- Landscape mode
- The app requests the highest refresh-rate display mode the device exposes.
