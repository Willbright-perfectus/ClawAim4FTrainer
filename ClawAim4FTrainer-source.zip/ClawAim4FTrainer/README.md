# ClawAim 4F Trainer v1.3.0

Android four-finger aim trainer prototype tuned around a Delta Force-style Hold-ADS layout.

## v1.3.0 changes
- New branded ClawAim 4F Trainer launcher/home logo.
- New image-backed industrial live-fire training room with walls, lanes, crates and target mannequins.
- Camera pan/zoom/parallax gives the room a stronger first-person 3D feel.
- Added STATIC AIM drill: the round target stays screen-stationary while the crosshair and room move around it.
- Adjustable target size (30% to 130%) in Sensitivity settings.
- More realistic jump arc instead of a one-frame camera hop.
- M4A1-style baseline: 31 damage, 800 RPM, 45-round magazine, 2.64 s reload.
- Recoil tuned from supplied Control 76 / Stability 65 / Accuracy 63 references.
- Scope selection now changes ADS zoom from red dot through 12x+.
- Live FPS counter and ammo/reload display.
- All previous HUD editing, button-specific pressed colors, Hold ADS, lean, movement, sensitivity and training drills retained.
