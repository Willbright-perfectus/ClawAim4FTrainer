# ClawAim 4F Trainer v1.1.0

Android four-finger aim trainer tuned for a Delta Force-style Hold-ADS HUD.

## v1.1.0 changes
- Removed vibrator/haptic code from the fire path to eliminate OEM/HyperOS vibration crashes.
- Delta Force-inspired four-finger HUD preset based on the supplied screenshot.
- HUD editor supports dragging buttons and changing the selected button size.
- Full per-scope camera and firing sensitivity from Hip/1x through 12x+.
- Adjustable global horizontal/vertical swipe and firing sensitivity.
- Scope selector now cycles through the complete sensitivity set.
- FPS-style centered crosshair: the crosshair stays centered while the scene/camera moves, like a normal first-person shooter.
- Added pseudo-3D perspective training room with parallax and first-person weapon silhouette.
- Flick, Tracking, Target Switch, Reaction and Recoil drills retained.

## Build
The repository workflow can unzip this project and run `gradle assembleDebug`.
