# ClawAim 4F Trainer v1.4.0

Native Android four-finger aim trainer.

## v1.4.0
- Replaces the flat training-room image with a procedural perspective 3D room rendered from world-space geometry.
- Adds real room walls, floor, ceiling, beams, lights, crates, lane lines and a back wall that react to yaw, pitch, movement, crouch and jump.
- Adds a first-person assault-rifle foreground with both tactical hands/forearms visible.
- Keeps Hold ADS, lean, movement, recoil, target-size control, static-aim mode, HUD editing and per-scope sensitivity controls.


## v1.5.0 changes
- Added visible front barrier / movement limit
- Targets now render with perspective depth inside the room
- Added Aim Y toggle (NORMAL / REVERSE)


## v1.6.0 changes
- Same procedural 3D room geometry with richer solid tactical colors
- Stronger concrete/metal wall structure, colored armour panels, yellow service pipes and hazard bands
- More colorful cover props and a higher-contrast barrier/back wall


## v1.7.0
- Added Lean Auto ADS toggle (ON by default)
- Added adjustable recoil weapon/hand kick visual
- Reload countdown now appears inside the reload button
- Added TAP TRAIN mode for HUD finger-speed and reaction practice
